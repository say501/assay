package com.sk.services.css.management.model.tranform;

import java.util.Map;

import javax.xml.stream.events.XMLEvent;

import com.amazonaws.transform.StaxUnmarshallerContext;
import com.amazonaws.transform.Unmarshaller;
import com.sk.services.css.management.model.ListClusterStatusResult;

public class ListClusterStatusResultStaxUnmarshaller implements Unmarshaller<ListClusterStatusResult, StaxUnmarshallerContext> {
	@Override
	public ListClusterStatusResult unmarshall(StaxUnmarshallerContext context) throws Exception {
		ListClusterStatusResult listClusterStatusResult = new ListClusterStatusResult();
		int originalDepth = context.getCurrentDepth();
		int targetDepth = originalDepth + 1;

		if (context.isStartOfDocument())
			targetDepth += 2;

		while (true) {
			XMLEvent xmlEvent = context.nextEvent();
			if (xmlEvent.isEndDocument())
				return listClusterStatusResult;

			if (xmlEvent.isAttribute() || xmlEvent.isStartElement()) {
				if (context.testExpression( "Status", targetDepth )) {
					Map<String, String> unmarshall = ClusterStatusStaxUnmarshaller.getInstance().unmarshall( context );
					listClusterStatusResult.getListClusterStatus().putAll( unmarshall );// ( "Status", ClusterStatusStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
			} else if (xmlEvent.isEndElement()) {
				if (context.getCurrentDepth() < originalDepth) {
					return listClusterStatusResult;
				}
			}
		}
	}

	private static ListClusterStatusResultStaxUnmarshaller instance;

	public static ListClusterStatusResultStaxUnmarshaller getInstance() {
		if (instance == null)
			instance = new ListClusterStatusResultStaxUnmarshaller();
		return instance;
	}
}
