package stats;

import java.util.List;
import java.util.Map;

import com.amazonaws.auth.BasicAWSCredentials;
import com.sk.services.css.management.CSSManagementClient;
import com.sk.services.css.management.Headers;
import com.sk.services.css.management.model.Cluster;

public class TS104 {
	
	private final static String accessKeyId = "YANK0APMIDACKO23PEAN";
	private final static String secretAccessKey = "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";
	private final static String iamUrl = "iam.skcloud.com";
	private final static int methodInterval = 100*1;

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		CSSManagementClient mgmt = new CSSManagementClient(
				new BasicAWSCredentials(accessKeyId, secretAccessKey));
		
		mgmt.setEndpoint(iamUrl);
		
		TS104 ts104 = new TS104();
		ts104.sleep(methodInterval);
		
		ts104.TS104_01(mgmt);
		
		ts104.TS104_02(mgmt, "/cluster02");
		ts104.sleep(methodInterval);
		
		ts104.TS104_03(mgmt, "/cluster02");
		ts104.sleep(methodInterval);
		
		ts104.TS104_04(mgmt, "/cluster02");
		ts104.sleep(methodInterval);
		
		ts104.TS104_06(mgmt, "/cluster02");
		ts104.sleep(methodInterval);
		
		ts104.TS104_07(mgmt, "/cluster02");
		ts104.sleep(methodInterval);
		
		ts104.TS104_08(mgmt, "/cluster02");
		ts104.sleep(methodInterval);
		
		ts104.TS104_09(mgmt, "/cluster02");
		ts104.sleep(methodInterval);
		
		ts104.TS104_10(mgmt, "bucket1");
		ts104.sleep(methodInterval);
		
		ts104.TS104_11(mgmt, "bucket1");
		ts104.sleep(methodInterval);
		
		ts104.TS104_12(mgmt, "bucket1", "/folder1");
		ts104.sleep(methodInterval);
		
		ts104.TS104_13(mgmt, "bucket1", "/folder1");
		ts104.sleep(methodInterval);

	}
	
	
	/** 전체 클러스터 목록 조회  
	 * @throws Exception **/
	public void TS104_01 (CSSManagementClient mgmt) throws Exception {
		
		System.out.println("========== TS01: 전체 클러스터 목록 조회 ==========");
		List<Cluster> clusterList= mgmt.listCluster( );
		for(Cluster cluster : clusterList) {
			System.out.println("클러스터 " + cluster);
		}
	}
	
	/** 지정한 클러스터의 현재 상태 조회  **/
	public void TS104_02 (CSSManagementClient mgmt, String volumeName) {
		
		System.out.println("========== TS02: 지정한 클러스터의 현재 상태 조회 ==========");
		Map<String, String> statusMap = mgmt.listClusterStatus( volumeName  );
		for(Map.Entry<String, String> entry : statusMap.entrySet()) {
			System.out.println(entry);
		}
	}
	
	/** 지정한 클러스터의 폴더타입 오브젝트 개수조회  **/
	public void TS104_03 (CSSManagementClient mgmt, String volumeName) {
		
		System.out.println("========== TS03: 지정한 클러스터의 폴더타입 오브젝트 개수조회 ==========");
//		Map<String, String> statusMap = mgmt.listClusterStatus( volumeName  );
		long foldercnt = mgmt.getClusterCount(volumeName, Headers.MODE_PHYSICAL, Headers.KEY_TYPE_FOLDER);
//		for(Map.Entry<String, String> entry : statusMap.entrySet()) {
			System.out.println("Cluster: "+volumeName+" has "+ foldercnt +" folders");
//		}
	}
	
	/** 지정한 클러스터의 파일타입 오브젝트 개수조회  **/
	public void TS104_04 (CSSManagementClient mgmt, String volumeName) {
		
		System.out.println("========== TS04: 지정한 클러스터의 파일타입 오브젝트 개수조회 ==========");
		long foldercnt = mgmt.getClusterCount(volumeName, Headers.MODE_PHYSICAL, Headers.KEY_TYPE_FILE);
			System.out.println("Cluster: "+volumeName+" has "+ foldercnt +" files");
//		}
	}
	
	
	/** 지정한 클러스터의 전체 Usable 사용량 조회  **/
	public void TS104_06 (CSSManagementClient mgmt, String volumeName) {
		
		System.out.println("========== TS06: 지정한 클러스터의 현재 상태 조회 ==========");
		long size = mgmt.getClusterSize( volumeName, Headers.MODE_USABLE  );
		System.out.println("스토리지 전체 Usable 사용량 조회: " + size);
	}
	
	/** 지정한 클러스터의 Physical 사용량 조회  **/
	public void TS104_07 (CSSManagementClient mgmt, String volumeName) {
		
		long size = mgmt.getClusterSize( volumeName, Headers.MODE_PHYSICAL  );
		System.out.println("스토리지 전체 Physical 사용량 조회: " + size);
	}
	
	/** 지정한 클러스터의  Usable 남은 용량 조회  **/
	public void TS104_08 (CSSManagementClient mgmt, String volumeName) {
		
		long size = mgmt.getClusterFreeSize(volumeName, Headers.MODE_USABLE);
		System.out.println("스토리지 전체Usable 남은용량: " + size);
	}
	
	/** 지정한 클러스터의  Physical 남은 용량 조회  **/
	public void TS104_09 (CSSManagementClient mgmt, String volumeName) {
		
		long size = mgmt.getClusterFreeSize(volumeName, Headers.MODE_PHYSICAL);
		System.out.println("스토리지 전체 Physical 남은용량: " + size);
	}
	
	/** BUCKET별 전체 Usable 사용량 조회 **/
	public void TS104_10 (CSSManagementClient mgmt, String bucketName) {
		
		long size = mgmt.getObjectSize( bucketName, "/", Headers.MODE_USABLE  );
		System.out.println("BUCKET별 전체 Usable 사용량 조회: " + size);
	}
	
	/** BUCKET별 전체 Physical 사용량 조회 **/
	public void TS104_11 (CSSManagementClient mgmt, String bucketName) {
		
		long size = mgmt.getObjectSize( bucketName, "/", Headers.MODE_PHYSICAL  );
		System.out.println("BUCKET별 전체 Physical 사용량 조회: " + size);
	}
	
	/** 폴더 타입 오브젝트 개수 조회 **/
	public void TS104_12 (CSSManagementClient mgmt, String bucketName, String path) {
		
		long count = mgmt.getObjectCount( bucketName, path, Headers.MODE_USABLE, Headers.KEY_TYPE_FOLDER  );
		System.out.println("폴더 타입 오브젝트 전체 Usable 사용량 조회: " + count);
	}
	
	/** 파일 타입 오브젝트 개수 조회 **/
	public void TS104_13 (CSSManagementClient mgmt, String bucketName, String path) {
		
		long count = mgmt.getObjectCount( bucketName, path, Headers.MODE_PHYSICAL, Headers.KEY_TYPE_FILE  );
		System.out.println("파일 타입 오브젝트 전체 Physical 사용량 조회: " + count);
	}

	
	public void sleep(int interval) {
		try {
			Thread.sleep(interval);
		} catch (InterruptedException e) {
		}
	}
}
