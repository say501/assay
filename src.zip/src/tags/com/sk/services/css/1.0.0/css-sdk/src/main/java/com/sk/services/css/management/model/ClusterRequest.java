package com.sk.services.css.management.model;

import com.amazonaws.AmazonWebServiceRequest;

public class ClusterRequest extends AmazonWebServiceRequest {
	private String BucketName;
	private String Key;
	private String volumeName;
	private String mode;
	private String type;

	public ClusterRequest(String volumeName, String mode) {
		this.volumeName = volumeName;
		this.mode = mode;
	}

	public ClusterRequest() {
	}

	public String getBucketName() {
		return BucketName;
	}

	public String getKey() {
		return Key;
	}

	public String getVolumeName() {
		return volumeName;
	}

	public String getMode() {
		return mode;
	}

	public String getType() {
		return type;
	}

	public void setBucketName(String bucketName) {
		BucketName = bucketName;
	}

	public void setKey(String key) {
		Key = key;
	}

	public void setVolumeName(String volumeName) {
		this.volumeName = volumeName;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ClusterRequest withBucketName(String bucketName) {
		BucketName = bucketName;
		return this;
	}

	public ClusterRequest withKey(String key) {
		Key = key;
		return this;
	}

	public ClusterRequest withVolumeName(String volumeName) {
		this.volumeName = volumeName;
		return this;
	}

	public ClusterRequest withMode(String mode) {
		this.mode = mode;
		return this;
	}

	public ClusterRequest withType(String type) {
		this.type = type;
		return this;
	}
}
