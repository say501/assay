package com.sk.services.css.sample;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.ProgressEvent;
import com.amazonaws.services.s3.model.ProgressListener;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.amazonaws.services.s3.model.UploadPartResult;

/**
 * <p>
 * 오브젝트 멀티파트 업로드를 위한 파트 업로드 쓰레드.
 * </p>
 *
 */
public class Uploader extends Thread
{
	private ObjectSample parent;
	private UploadPartRequest uploadReq;
	private List<PartETag> partETags;
	
	private static long totalSize = 0;
	private static boolean isFinished = false;
	
	private static final AtomicInteger alive = new AtomicInteger ();
	
	private static final Log log = LogFactory.getLog (ObjectSample.class);
	
	/**
	 * <p>
	 * 현재까지 업로드 된 총 크기를 가져온다(파트 통합).
	 * </p>
	 * 
	 * @return	현재까지 업로드 된 총 용량
	 */
	public static long getTotalSize ()
	{
		return totalSize;
	}
	
	/**
	 * <p>
	 * 모든 파트가 업로가 완료되었는지 확인한다.
	 * </p>
	 * 
	 * @return	true - 모든 파트 업로드가 완료됐음, false - 아직 파트가 업로드 중에 있음.
	 */
	public static boolean isFinished ()
	{
		return isFinished;
	}
	
	/**
	 * <p>
	 * 파트 업로드를 위한 Sub Thread 생성자.
	 * </p>
	 * 
	 * @param 	parent ObjectSample 오브젝트
	 * @param 	req UploadPartRequest 모델
	 * @param 	partETags 
	 */
	public Uploader (ObjectSample parent, UploadPartRequest req, List<PartETag> partETags)
	{
		this.parent = parent;
		this.uploadReq = req;
		this.partETags = partETags;
		
		this.uploadReq.setProgressListener 
		(					
			new ProgressListener ()
			{				
				@Override
				public void progressChanged (ProgressEvent progressEvent)
				{
					totalSize += progressEvent.getBytesTransfered ();
				}
			}
		);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	@Override
	public void run ()
	{
		alive.incrementAndGet ();
		
		do
		{
			try
			{
				// Upload part
				UploadPartResult uploadPartResult = parent.s3.uploadPart (this.uploadReq);
				
				// Add etag value of uploaded part
				partETags.add (new PartETag (this.uploadReq.getPartNumber (), uploadPartResult.getETag ()));
				
				// The end thread
				break;
			}
			catch (Exception e)
			{
				log.error (e);
				
				// Have delay time for 5 seconds.
				try {sleep (5000);}catch (InterruptedException ie) {;}
			}
		}	while (true);
		
		alive.decrementAndGet ();
		
		if (alive.get () == 0)
		{
			System.out.println ("Process complete!");
			
			// Mark finish flag
			isFinished = true;
			
			// Complete multipart upload & merge the parts
			parent.s3.completeMultipartUpload (new CompleteMultipartUploadRequest (this.uploadReq.getBucketName (), 
																				   this.uploadReq.getKey (), 
																				   this.uploadReq.getUploadId (), 
																				   this.partETags));
		}
	}	
}