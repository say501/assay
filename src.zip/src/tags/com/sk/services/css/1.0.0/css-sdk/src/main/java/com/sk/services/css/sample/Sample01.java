package com.sk.services.css.sample;

import java.io.File;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectMetadataRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.ListMultipartUploadsRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.Region;

/**
 * <p>
 * AmazonS3 & SK CSS SDK 예제 코드.
 * </p>
 * <p>
 * AmazonS3 기본 기능 예제 코드 (버킷 및 오브젝트 관리)
 * </p>
 * 
 */
public class Sample01
{
	public static void main (String[] args)
	{
		// 기본 사용자 정보 (보안키, 인증키)
		String accessKeyId = "YANK0APMIDACKO23PEAN";
		String secretAccessKey = "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";
		
		// 사용자 인증 설정
		CredentialSample cr = new CredentialSample (accessKeyId, secretAccessKey);
		
		// 인증된 AmazonS3 인스턴스를 얻어온다.
		AmazonS3 s3 = cr.getAuthenticatedInstance ();
		
		s3.setEndpoint ("http://s3.skcloud.com");
		
		/********************************************************************************************
		 * 버킷 관련 기능
		 ********************************************************************************************/
		BucketSample bucketSample = new BucketSample (s3);
		switch (-1)
		{
			case 0:
				// 버킷 목록 보기
				bucketSample.printBucketList ();
				break;
			case 1:
				// 버킷 정보 보기
				bucketSample.printBucketInfo ("bucket-501");
				break;
			case 2:
				// 버킷 만들기
				bucketSample.createBucket (new CreateBucketRequest ("bucket02", Region.AP_Tokyo)); 
				break;
			case 3:
				// 버킷 삭제하기
				bucketSample.deleteBucket ("bucket02");
				break;
			case 4:
				// 버킷 위치 가져오기
				bucketSample.printBucketLocation ("bucket01");
				break;
		}
		
		/********************************************************************************************
		 * 오브젝트 관련 기능
		 ********************************************************************************************/
		ObjectSample objectSample = new ObjectSample (s3);
		switch (-1)
		{
			case 0:
				// 버킷 내 오브젝트 목록 보기
				objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("bucket01"));
				break;
			case 1:
				// 버킷 내 특정 폴더 오브젝트 목록 보기
				objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("ryan1").withPrefix (""));
				break;
			case 2:
				// 오브젝트 기본 정보 보기
				objectSample.printObjectInfo (new GetObjectRequest ("501", "1.txt"));
				break;
			case 3:
				// 오브젝트의 메타 정보 보기
				objectSample.printObjectMetadata (new GetObjectMetadataRequest ("bucket", "folder/tbag2.tar"));
				break;
			case 4:
				// 오브젝트 올리기
				ObjectMetadata metadata = new ObjectMetadata ();
				metadata.addUserMetadata ("a", "hh");
				metadata.addUserMetadata ("d", "1111");
				
				PutObjectRequest req = new PutObjectRequest ("bucket01", "test.pdf", new File ("D://", "test.pdf"));
				req.setMetadata (metadata);
				
				objectSample.uploadObjectByPut (req);
				break;
			case 5:
				// 오브젝트를 삭제한다.
				objectSample.deleteObject (new DeleteObjectRequest ("502", "a/version.ini"));
				break;
			case 6:
				// 멀티파트 업로드 목록 보기
				objectSample.printMultipartUploadList (new ListMultipartUploadsRequest ("ryan"));
				break;
			case 7:
				// 오브젝트 멀티파트 업로드 하기
				// Not use multi thread.
				objectSample.uploadObjectByMultipart (new InitiateMultipartUploadRequest ("ryan", "restlet-1.1.10.zip"));
				// Use multi thread.
				//objectSample.uploadObjectByMultipartByThread (new InitiateMultipartUploadRequest ("ryan", "restlet-1.1.10.zip"));
				break;
			case 8:
				// 예약된 멀티파트 업로드를 취소한다.
				objectSample.abortMultipartUpload (new AbortMultipartUploadRequest ("501", "restlet-1.1.10.zip", "s6Xf89vFCTSdocsWbblgHyf3gCU="));
				break;
			case 9:
				// 오브젝트 ACL을 가져온다.
				objectSample.getObjectAcl ("502", "");
				break;
		}
	}
}
