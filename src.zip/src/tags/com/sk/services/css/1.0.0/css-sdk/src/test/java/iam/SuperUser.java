package iam;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagement;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagementClient;
import com.amazonaws.services.identitymanagement.model.Group;
import com.amazonaws.services.identitymanagement.model.ListGroupsRequest;
import com.amazonaws.services.identitymanagement.model.ListGroupsResult;

public class SuperUser {
	private final static String accessKeyId = "YANK0APMIDACKO23PEAN";
	private final static String secretAccessKey = "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";
	private final static String devUrl = "iam.skcloud.com";

	private AmazonIdentityManagement iam;

	@Before
	public void setUp() throws Exception {
		iam = new AmazonIdentityManagementClient( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		iam.setEndpoint( devUrl );
	}

	@Test
	public void test() {
		ListGroupsRequest request = new ListGroupsRequest();
		request.setPathPrefix( "/" );

		ListGroupsResult listGroups = iam.listGroups( request );
		for (Group group : listGroups.getGroups()) {
			System.out.println( group.toString() );
		}
	}
}
