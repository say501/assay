package performance.iam;

import static org.junit.Assert.assertNotNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagement;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagementClient;
import com.amazonaws.services.identitymanagement.model.AccessKey;
import com.amazonaws.services.identitymanagement.model.AddUserToGroupRequest;
import com.amazonaws.services.identitymanagement.model.CreateAccessKeyRequest;
import com.amazonaws.services.identitymanagement.model.CreateAccessKeyResult;
import com.amazonaws.services.identitymanagement.model.CreateUserRequest;
import com.amazonaws.services.identitymanagement.model.CreateUserResult;
import com.amazonaws.services.identitymanagement.model.User;

public class CreatUser {

	private final static String			accessKeyId		= "YANK0APMIDACKO23PEAN";
	private final static String			secretAccessKey	= "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";
	private final static String			devUrl			= "iam.skcloud.com";

	private AmazonIdentityManagement	iam;

	@Before
	public void setUp() throws Exception {
		iam = new AmazonIdentityManagementClient( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		iam.setEndpoint( devUrl );
	}

	@Test
	public void testIAM_CreateUser() {
		CreateUserRequest request = new CreateUserRequest();
		String userName = "U-" + getName();
		request.setUserName( userName );
		CreateUserResult userResult = iam.createUser( request );
		User user = userResult.getUser();

		Assert.assertEquals( userName, user.getUserName() );
		Assert.assertEquals( userName, user.getUserId() );
		System.out.println( user.toString() );
		
		AddUserToGroupRequest autgRequest = new AddUserToGroupRequest();
		autgRequest.setGroupName( "G-20110819163722" );
		autgRequest.setUserName( userName );
		iam.addUserToGroup( autgRequest );
		
		
		CreateAccessKeyRequest cakRequest = new CreateAccessKeyRequest();
		cakRequest.setUserName( userName);
		
		CreateAccessKeyResult createAccessKey = iam.createAccessKey( cakRequest );
		AccessKey accessKey = createAccessKey.getAccessKey();
		assertNotNull( accessKey );
		System.out.println( accessKey.toString() );
	}

	public static String getName() {
		SimpleDateFormat formatter = new SimpleDateFormat( "yyyyMMddHHmmss", Locale.KOREA );
		return formatter.format( new Date() );
	}
}
