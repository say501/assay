package ext;

import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.sk.services.css.AmazonS3ClientExt;
import com.sk.services.css.AmazonS3Ext;
import com.sk.services.css.model.Publishing;

public class AmazonExtTest {
	private final static String accessKeyId = "YANK0APMIDACKO23PEAN";
	private final static String secretAccessKey = "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";
	private String devUrl = "http://s3.skcloud.com";
	private AmazonS3Ext client = null;

	@Before
	public void setUp() throws Exception {
		client = new AmazonS3ClientExt( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		assertNotNull( client );
		client.setEndpoint( devUrl );
	}

	@Test
	public void test_CreateDirectory() {
		String bucketName = "ADSF";
		String key = "QERW";
		client.createDirectory( bucketName, key );
	}

	@Test
	public void test_SetObjectMetadata() {
		String bucketName = "ryan";
		String key = "test.pdf";
		
		@SuppressWarnings("serial")
		Map<String, Object> metadata = new HashMap<String, Object>() {{
			put( "1", "one" );
			put( "2", "two" );
			put( "3", "three" );
			put( "4", "four" );
			put( "5", "five" );
		}};
		
		client.setObjectMetadata( bucketName, key, metadata );
	}

	@Test
	public void test_DeleteObjectMetadata() {
		String bucketName = "ryan";
		String key = "test.pdf";
		String metadataKey = "one";
		client.deleteObjectMetadata( bucketName, key, metadataKey );
	}

	@Test
	public void test_PutPublishing() {
		String bucketName = "ryan";
		String key = "test.pdf";
		
		Publishing result = client.putPublishing( bucketName, key );
		
		assertNotNull( result );
		System.out.println( result.toString() );
	}

	@Test
	public void test_PutPublishing_Using_Publishing() {
		String bucketName = "ryan";
		String key = "test.pdf";
		
		SimpleDateFormat formatter = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss", Locale.KOREA );
		String format = formatter.format( new Date() );
		
		System.out.println( format );
		
		Publishing pub = new Publishing();
		pub.setGeneratedUri( "GeneralURI" );
		pub.setExpireDate( Timestamp.valueOf( format ) );
		
		Publishing result = client.putPublishing( bucketName, key, pub );
		
		assertNotNull( result );
		System.out.println( result.toString() );
	}
}
