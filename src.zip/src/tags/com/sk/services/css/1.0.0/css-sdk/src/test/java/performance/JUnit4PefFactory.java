package performance;

import junit.framework.JUnit4TestAdapter;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TestFactory;

/**
 * 
 * @author Ryan GG Ahn
 *
 */
public class JUnit4PefFactory extends TestFactory {

	private Class<?> junitTestsClass;

	static class DummyTestCase extends TestCase {
		public void test() {

		}
	}

	@SuppressWarnings("rawtypes")
	public JUnit4PefFactory(Class testClass) {
		super( DummyTestCase.class );
		this.junitTestsClass = testClass;
	}

	@Override
	public TestSuite makeTestSuite() {
		JUnit4TestAdapter adapter = new JUnit4TestAdapter( this.junitTestsClass );
		TestSuite testSuite = new TestSuite( "JUnit4TestFactory" );
		testSuite.addTest( adapter );

		return testSuite;
	}
}

