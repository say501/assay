package com.sk.services.css.management;

import java.util.Map;

import com.amazonaws.ResponseMetadata;

/**
 * <p>
 * AWS의 ResponseMetadata의 확장 클래스이다. SK CSS request ID는 모든 서비스에 포함되어 있고, SK CSS는 SK CSS 디버깅을 위해 제공되는 host ID를 포함한다.
 * </p>
 *
 */
public class CSSResponseMetadata extends ResponseMetadata
{
	public static final String HOST_ID = "";
	
	/**
	 * <p>
	 * 메타 데이터 정보에 기술된 맵 데이터로 부터 새로운 ResponseMetadata를 생성한다.
	 * </p>
	 * 
	 * @param 	metadata 새로운 ResponseMetadata 오브젝트를 위한 메타 데이터 정보.
	 */
	public CSSResponseMetadata (Map<String, String> metadata)
	{
		super (metadata);
	}
	
	/**
	 * <p>
	 * 이미 존재하는 ResponseMetadata 오브젝트로부터 새로운 ResponseMetadata를 생성한다.
	 * </p>
	 * 
	 * @param 	originalResponseMetadata 새로운 ResponseMetadata를 생성하기 위한 ResponseMetadata 오브젝트.
	 */
	public CSSResponseMetadata (ResponseMetadata originalResponseMetadata)
	{
		super (originalResponseMetadata);
	}
	
	/**
	 * <p>
	 * Request가 핸들링 되는 방법에 대해 추가적인 디버깅 정보를 제공하기 위해 SK CSS host ID를 반환한다. host ID를 이용해 Troubleshoot issues에 대해 지원받을 수 있다.
	 * </p>
	 * 
	 * @return 	SK CSS host ID를 반환한다.
	 */
	public String getHostId ()
	{
		return HOST_ID;
	}
}
