package performance.s3;

import java.net.UnknownHostException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import performance.S3Test;
import performance.util.S3TestUtil;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.Region;

public class CreateBucket extends S3Test{
	static final Log log = LogFactory.getLog (CreateBucket.class);

	/**
	 * Creates bucket that is randomly named and concatenated by the creation date 
	 * @throws Exception
	 */
	@Test
	public void testCreateBucket() {
		String bucketName;
		try {
			synchronized(this){
				bucketName = S3TestUtil.createBucketName();
			}
			this.s3.createBucket (new CreateBucketRequest(bucketName, Region.AP_Tokyo));
		} catch (UnknownHostException e) {
			assertFalse(true);
		}	
	}
}
