package a_customerTest;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagement;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagementClient;
import com.amazonaws.services.identitymanagement.model.AccessKeyMetadata;
import com.amazonaws.services.identitymanagement.model.AddUserToGroupRequest;
import com.amazonaws.services.identitymanagement.model.CreateUserRequest;
import com.amazonaws.services.identitymanagement.model.CreateUserResult;
import com.amazonaws.services.identitymanagement.model.DeleteUserRequest;
import com.amazonaws.services.identitymanagement.model.ListAccessKeysRequest;
import com.amazonaws.services.identitymanagement.model.ListAccessKeysResult;
import com.amazonaws.services.identitymanagement.model.ListUsersRequest;
import com.amazonaws.services.identitymanagement.model.ListUsersResult;
import com.amazonaws.services.identitymanagement.model.User;
import com.sk.services.css.management.AccessKeySpliter;

public class TS101_01_to_02 {
	private final static String accessKey = "AKIAIFFCMOS3ZSOMLD7A";
	private final static String secretKey = "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";

	private final static String accessKeyId = "YANK0APMIDACKO23PEAN";
	private final static String secretAccessKey = "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";
	private final static String devUrl = "iam.skcloud.com";

	private AmazonIdentityManagement iam;

	@Before
	public void setUp() throws Exception {
		iam = new AmazonIdentityManagementClient( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		iam.setEndpoint( devUrl );
	}

	@Test
	public void TS101_TC_01_Test(){
		this.TS101_TC_01();
	}
	@Test
	public void TS101_TC_02_Test() throws Exception{
		this.TS101_TC_02();
	}
	
	
	
		
	
	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void TS101_TC_01() { // testIAM_CreateUser()
		CreateUserRequest request = new CreateUserRequest();
		String userName = "U-" + getName();
		request.setUserName( userName );
		CreateUserResult userResult = iam.createUser( request );
		User user = userResult.getUser();

		Assert.assertEquals( userName, user.getUserName() );
		Assert.assertEquals( userName, user.getUserId() );
		System.out.println( user.toString() );
	}

	@Test
	public void TS101_TC_02() throws Exception { // test_DeleteUser() 
		DeleteUserRequest request = new DeleteUserRequest();
		request.setRequestCredentials( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		request.setUserName( "U-testuser" );
		//request.setUserName( "U-20110824174206" );
		iam.deleteUser( request );
	}


	@Test
	public void testAIM_ListUsers() {
		AmazonIdentityManagement aim = new AmazonIdentityManagementClient( new BasicAWSCredentials( accessKey, secretKey ) );

		ListUsersRequest request = new ListUsersRequest();
		request.setPathPrefix( "/" );

		System.out.println( "User Info ==> " );
		ListUsersResult listUsers = aim.listUsers( request );
		for (User user : listUsers.getUsers()) {
			System.out.println( user.toString() );
		}
	}

	@Test
	public void testIAM_ListUsers() {
		ListUsersRequest request = new ListUsersRequest();
		request.setPathPrefix( "/" );

		System.out.println( "User Info ==> " );
		ListUsersResult listUsers = iam.listUsers( request );
		for (User user : listUsers.getUsers()) {
			System.out.println( user.toString() );
			
			System.out.println( "User Name ==> " + user.getUserName() );
			ListAccessKeysRequest listAkReq = new ListAccessKeysRequest();
			listAkReq.setUserName( user.getUserName() );
			ListAccessKeysResult listKeys = iam.listAccessKeys( listAkReq );

			for (AccessKeyMetadata meta : listKeys.getAccessKeyMetadata()) {
				String[] split = meta.getAccessKeyId().split( AccessKeySpliter.FIELD );
				System.out.println( "AccessKeyId ==> " + " ==> " + split[0] );
				System.out.println( "SecretAccessKey ==> " + " ==> " + split[1] );
			}
		}
	}
	
	
	
	@Test
	public void test_AddToGroup() throws Exception {
		AddUserToGroupRequest request = new AddUserToGroupRequest();
		request.setGroupName( "G-20110824174122" );
		request.setUserName( "U-20110824174235" );
		iam.addUserToGroup( request );
	}

	public static String getName() {
//		SimpleDateFormat formatter = new SimpleDateFormat( "yyyyMMddHHmmss", Locale.KOREA );
//		return formatter.format( new Date() );
		String name = "testuser";
		return name;
	}
}
