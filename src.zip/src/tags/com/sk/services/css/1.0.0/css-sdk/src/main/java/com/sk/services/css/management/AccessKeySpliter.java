package com.sk.services.css.management;

public class AccessKeySpliter {
	/**
	 * AccessKeyId와 SecretAccessKey 사이 구분자
	 */
	public static final String FIELD = "#::#";
}
