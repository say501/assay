package com.sk.services.css.model.tranform;

import com.amazonaws.DefaultRequest;
import com.amazonaws.Request;
import com.amazonaws.util.StringUtils;
import com.sk.services.css.model.ExtClientRequest;
import com.sk.services.css.model.Publishing;

public class ExtClientRequestMarshaller {
	public Request<ExtClientRequest> marshall(ExtClientRequest extClientRequest, String action) {
		Request<ExtClientRequest> request = new DefaultRequest<ExtClientRequest>( extClientRequest, "AmazonS3ClientExt" );

		request.addParameter( "Action", action );
		request.addParameter( "Version", "2011-08-21" );

		if (extClientRequest != null) {
			if (extClientRequest.getBucketName() != null) {
				request.addParameter( "BucketName", StringUtils.fromString( extClientRequest.getBucketName() ) );
			}
		}

		if (extClientRequest != null) {
			if (extClientRequest.getKey() != null) {
				request.addParameter( "Key", StringUtils.fromString( extClientRequest.getKey() ) );
			}
		}
		if (extClientRequest != null) {
			if (extClientRequest.getMetadataKey() != null) {
				request.addParameter( "MetadataKey", StringUtils.fromString( extClientRequest.getMetadataKey() ) );
			}
		}

		if (extClientRequest != null) {
			if (extClientRequest.getSourceBucketName() != null) {
				request.addParameter( "SourceBucketName", StringUtils.fromString( extClientRequest.getSourceBucketName() ) );
			}
		}

		if (extClientRequest != null) {
			if (extClientRequest.getDestinationBucketName() != null) {
				request.addParameter( "DestinationBucketName", StringUtils.fromString( extClientRequest.getDestinationBucketName() ) );
			}
		}
		
		if (extClientRequest != null) {
			if (extClientRequest.getDestinationKey() != null) {
				request.addParameter( "DestinationKey", StringUtils.fromString( extClientRequest.getDestinationKey() ) );
			}
		}
		
		if (extClientRequest != null) {
			if (extClientRequest.getPublishing() != null) {
				Publishing publishing = extClientRequest.getPublishing();
				if (publishing.getGeneratedUri() != null) {
					request.addParameter( "GeneratedUri", StringUtils.fromString( publishing.getGeneratedUri() ) );
				}
				
				if (publishing.getExpireDate() != null) {
					request.addParameter( "ExpireDate", StringUtils.fromString( publishing.getExpireDate().toString() ) );
				}
			}
		}

		return request;
	}
}
