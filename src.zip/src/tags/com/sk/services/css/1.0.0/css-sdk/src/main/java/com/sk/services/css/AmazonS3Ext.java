package com.sk.services.css;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Node;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.QueryStringSigner;
import com.amazonaws.handlers.HandlerChainFactory;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.transform.StandardErrorUnmarshaller;
import com.amazonaws.transform.Unmarshaller;
import com.sk.services.css.management.exception.CSSException;
import com.sk.services.css.model.Publishing;

/**
 * <p>
 * 이 클래스는 AmazoneS3Client의 확장 클래스로 추가 API를 갖고 있다.
 * </p>
 * <p>
 * 추가된 API는 오브젝트 이동, 이름 바꾸기 그리고 공유 설정 관련 메소드가 추가되었으며, AmazonS3Client의 모든 기능 또한 포함한다. 
 * 만약 AmazonS3 서비스를 이용하고자 한다면, AmazonS3Client만으로 이용이 가능하지만, SK CSS서비스를 이용하고자 한다면, AmazonS3Ext를 이용하면 추가 기능을
 * 이용할 수 있다. 단, AmazonS3Client를 이용하면 추가 기능(오브젝트 이동, 이름 바꾸기, 공유 설정 등)을 이용할 수가 없다.
 * </p>
 * <p>
 * <blockquote><pre>
 * // Native AmazonS3 Class를 사용할 때 
 * AmazonS3 = new AmazonS3Client ();
 * 
 * // Extended AmazonS3 Class를 사용할 때
 * AmazonS3Ext = new AmazonS3ClientExt ();
 * </pre></blockquote>
 * </p>
 * 
 * @see 	com.amazonaws.services.s3.AmazonS3Client
 *
 */
public abstract class AmazonS3Ext extends AmazonS3Client
{
	protected AWSCredentials awsCredentials;
	protected final List<Unmarshaller<AmazonServiceException, Node>> exceptionUnmarshallers;

	protected QueryStringSigner signer;
	
//	public AmazonS3Ext ()
//	{
//		super ();
//	}
	
	public AmazonS3Ext (AWSCredentials awsCredentials)
	{
		this (awsCredentials, new ClientConfiguration());
	}
	
	public AmazonS3Ext (AWSCredentials awsCredentials, ClientConfiguration clientConfiguration)
	{
		super (awsCredentials, clientConfiguration);
		
		this.awsCredentials = awsCredentials;
		// TODO Exception 추가하거나 필요없는 부분 뺄 것.
		exceptionUnmarshallers = new ArrayList<Unmarshaller<AmazonServiceException, Node>>();
		exceptionUnmarshallers.add( new StandardErrorUnmarshaller() );

		// TODO HOST 명 setting 할 것.
		setEndpoint( "iam.localhost" );

		signer = new QueryStringSigner();

		HandlerChainFactory chainFactory = new HandlerChainFactory();
		requestHandlers.addAll( chainFactory.newRequestHandlerChain( "/com/sk/services/css/management/request.handlers" ) );
	}
	
	/**
	 * <p>
	 * 선택한 오브젝트의 이름을 변경한다.
	 * </p>
	 * <p>
	 * 오브젝트의 이름을 변경하지만, 위치는 변경되지 않는다.
	 * </p>
	 * 
	 * @param 	bucketName 오브젝트가 위치한 버킷 이름
	 * @param 	sourceKey 오브젝트 전체 경로
	 * @param 	newKey 변경할 오브젝트 이름 (전체 경로 아님).
	 * @throws 	AmazonClientException
	 * @throws 	AmazonServiceException
	 */
	public abstract void renameObject (String bucketName, String sourceKey, String newKeyName) 
		throws AmazonClientException, AmazonServiceException;
	
	/**
	 * <p>
	 * 선택한 오브젝트를 이동한다.
	 * </p>
	 * <p>
	 * 오브젝트를 다른 위치로 이동 시킨다. 최초 위치는 삭제 되고, 메타데이터 정보는 모두 복제된다.
	 * </p>
	 * 
	 * @param 	sourceBucketName 이동할 오브젝트가 있는 버킷 이름
	 * @param 	sourceKey 오브젝트 전체 경로
	 * @param 	destinationBucketName 최종으로 이동될 버킷 이름
	 * @param 	destinationKey 이동될 오브젝트 전체 경로
	 * @throws	AmazonClientException
	 * @throws 	AmazonServiceException
	 */
	public abstract void moveObject (String sourceBucketName, String sourceKey, String destinationBucketName, String destinationKey)  
		throws AmazonClientException, AmazonServiceException;
	
	/**
	 * <p>
	 * 선택한 오브젝트를 공유한다.
	 * </p>
	 * <p>
	 * 오브젝트를 익명의 사용자에게 공유하기 위한 URI를 생성한다. URI는 만료일자를 갖는다.
	 * </p>
	 * 
	 * @param 	bucketName 공유하고자 하는 오브젝트의 버킷 이름
	 * @param 	key 공유하고자하는 오브젝트 전체 경로
	 * @param 	pub 공유 설정 옵션
	 * @return	공유 오브젝트에 대한 접근 URI를 포함한 클래스
	 * @throws 	CSSException
	 * @see 	com.sk.services.css.model.Publishing
	 * @see		putPublishing(String, String)
	 */
	public abstract Publishing putPublishing (String bucketName, String key, Publishing pub) throws CSSException;
	
	/**
	 * <p>
	 * 선택한 오브젝트를 기본 설정 값으로 공유한다.
	 * </p>
	 * <p>
	 * 오브젝트를 익명의 사용자에게 공유하기 위한 URI를 생성한다. URI는 기본 만료일자를 갖는다. (Default expire date is 4 days)
	 * </p>
	 * 
	 * @param 	bucketName 공유하고자 하는 오브젝트의 버킷 이름
	 * @param 	key 공유하고자하는 오브젝트 전체 경로
	 * @param 	pub 공유 설정 옵션
	 * @return	공유 오브젝트에 대한 접근 URI를 포함한 클래스
	 * @throws 	CSSException
	 * @see 	com.sk.services.css.model.Publishing
	 * @see		putPublishing(String, String, Publishing)
	 */
	public abstract Publishing putPublishing (String bucketName, String key) throws CSSException;
	
	/**
	 * <p>
	 * 선택한 버킷에 폴더를 생성한다.
	 * </p>
	 * <p>
	 * 폴더 용도의 오브젝트 키를 생성한다. 이 오브젝트는 빈 파일이 아니며, Prefix용도로 사용될 수 있다.
	 * </p>
	 * 
	 * @param 	bucketName 폴더를 생성하고자 하는 위치의 버킷 이름
	 * @param	key 새로 생성할 폴더 전체 경로
	 * @throws 	CSSException
	 */
	public abstract void createDirectory (String bucketName, String key) throws CSSException;
	
	/**
	 * <p>
	 * 선택한 오브젝트의 메타데이터 정보를 추가하거나, 변경한다.
	 * </p>
	 * <p>
	 * 이 메소드를 이용하여 지정한 오브젝트의 메타데이터 정보를 추가할 수 있으며, 이미 존재하는 키 값일 경우 해당 키에 대한 값이 변경된다.
	 * </p>
	 * 
	 * @param 	bucketName 오브젝트가 위치한 버킷 이름
	 * @param 	key 메타데이터 정보를 삽입할 오브젝트 전체 경로
	 * @param 	metadata 삽입할 메타데이터 정보 (Key - Value)
	 * @throws 	CSSException
	 */
	public abstract void setObjectMetadata (String bucketName, String key, Map<String, Object> metadata) throws CSSException;
	
	/**
	 * <p>
	 * 선택한 오브젝트의 특정 메타데이터 정보를 삭제한다.
	 * </p>
	 * <p>
	 * 이 메소드를 이용하여 지정한 오브젝트의 메타데이터 정보의 키 값을 지정하여 삭제할 수 있다.
	 * </p>
	 * 
	 * @param 	bucketName 오브젝트가 위치한 버킷 이름
	 * @param 	key 메타데이터 정보를 삭제할 오브젝트 전체 경로
	 * @param 	metadataKey 삭제할 메타데이터 키 값
	 * @throws 	CSSException
	 */
	public abstract void deleteObjectMetadata (String bucketName, String key, String metadataKey) throws CSSException;
}
