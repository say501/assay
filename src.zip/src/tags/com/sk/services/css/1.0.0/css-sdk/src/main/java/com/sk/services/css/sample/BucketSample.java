package com.sk.services.css.sample;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.amazonaws.AmazonClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.CreateBucketRequest;

/**
 * <p>
 * Amazon S3 버킷 운영 관련 예제 코드.
 * </p>
 *
 */
public class BucketSample
{
	AmazonS3 s3;
	
	static final Log log = LogFactory.getLog (BucketSample.class);
	
	/**
	 * @deprecated 
	 */
	public BucketSample ()
	{
		
	}
	
	/**
	 * <p>
	 * BucketSample 확장 생성자
	 * </p>
	 * 
	 * @param 	s3 AmazonS3 인터페이스
	 * 
	 */
	public BucketSample (AmazonS3 s3)
	{
		this.s3 = s3;
	}
	
	/**
	 * <p>
	 * 버킷 목록을  보여준다.
	 * </p>
	 * 
	 */
	public void printBucketList ()
	{
		for (Bucket bucket : this.s3.listBuckets ()) 
		{
            System.out.println (" - " + bucket.toString ());
        }
	}
	
	/**
	 * <p>
	 * 지정한 버킷 정보를 보여준다.
	 * </p>
	 * 
	 * @param 	bucketName 버킷 이름
	 */
	public void printBucketInfo (String bucketName)
	{
		try
		{
			System.out.println (this.s3.getBucketLocation (bucketName));
			System.out.println (this.s3.getBucketAcl (bucketName).toString ());
			System.out.println (this.s3.getBucketPolicy (bucketName).toString ());
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 지정한 이름으로 버킷을 생성한다.
	 * </p>
	 * 
	 * @param 	bucketName 버킷 이름
	 */
	public void createBucket (CreateBucketRequest bucketName)
	{
		try
		{
			Bucket msg = this.s3.createBucket (bucketName);
			System.out.println (msg.toString ());
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 지정한 버킷을 삭제한다.
	 * </p>
	 * 
	 * @param 	bucketName 버킷 이름
	 */
	public void deleteBucket (String bucketName)
	{
		try
		{
			this.s3.deleteBucket (bucketName);
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 지정한 버킷의 위치 정보를 가져온다.
	 * </p>
	 * 
	 * @param 	bucketName 버킷 이름
	 */
	public void printBucketLocation (String bucketName)
	{
		try
		{
			String location = this.s3.getBucketLocation (bucketName);
			System.out.println (location);
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
}
