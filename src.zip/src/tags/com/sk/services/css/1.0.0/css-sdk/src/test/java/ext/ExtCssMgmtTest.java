package ext;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.sk.services.css.management.CSSManagement;
import com.sk.services.css.management.CSSManagementClient;
import com.sk.services.css.management.exception.CSSException;
import com.sk.services.css.management.model.Cluster;

public class ExtCssMgmtTest {
	private final static String accessKeyId = "7B61B4608BC71CF8GGC2";
	private final static String secretAccessKey = "6+fVCoCxiii/cR/oOokeNrafvcPEOSKT9CLkpgB/";
	private final static String devUrl = "iam.skcloud.com";

	private CSSManagement mgmt = null;

	@Before
	public void setUp() throws Exception {
		mgmt = new CSSManagementClient( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		assertNotNull( mgmt );
		mgmt.setEndpoint( devUrl );
	}

	@Test
	public void test_ListCluster() throws CSSException, Exception {
		List<Cluster> listCluster = mgmt.listCluster();
		assertNotNull( listCluster );

		for (Cluster cluster : listCluster) {
			System.out.println( cluster.toString() );
		}
	}

	@Test
	public void test_ListClusterStatus() {
		Map<String, String> listClusterStatus = mgmt.listClusterStatus( "cluster01" );
		assertNotNull( listClusterStatus );

		Iterator<String> iterator = listClusterStatus.keySet().iterator();
		while (iterator.hasNext()) {
			String key = iterator.next();
			System.out.println( key + ": " + listClusterStatus.get( key ) );
		}
	}

	@Test
	public void test_GetClusterCount() {
		String volumeName = "test";
		int mode = 0;
		int type = 0;
		long clusterCount = mgmt.getClusterCount( volumeName, mode, type );
		assertEquals( 0, clusterCount );
		System.out.println( clusterCount );
	}

	@Test
	public void test_GetClusterFreeSize() {
		String volumeName = "test";
		int mode = 0;
		long size = mgmt.getClusterFreeSize( volumeName, mode );
		System.out.println("returned Size: "+size);
		assertEquals( 6367456788480L, size );
		System.out.println( size );
	}

	@Test
	public void test_GetClusterSize() {
		String volumeName = "test";
		int mode = 0;
		long clusterSize = mgmt.getClusterSize( volumeName, mode );
		assertEquals( 133051750438L, clusterSize );
		System.out.println( clusterSize );
	}

	@Test
	public void test_GetObjectCount() {
		String key = "test";
		int mode = 0;
		int type = 0;
		long count = mgmt.getObjectCount( key, mode, type );
		assertEquals( 0, count );
		System.out.println( count );
	}

	@Test
	public void test_GetObjectCountByBucketName() {
		String bucketName = "/test";
		String key = "/";
		int mode = 0;
		int type = 0;
		long count = mgmt.getObjectCount( bucketName, key, mode, type );
		assertEquals( 10, count );
		System.out.println( count );
	}

//	@Test
//	public void test_GetObjectSize() {
//		String key = "";
//		int mode = 0;
//		long size = mgmt.getObjectSize( key, mode );
//		assertEquals( 10, size );
//		System.out.println( size );
//	}

	@Test
	public void test_GetObjectSizeByBucketName() {
		String bucketName = "test";
		String key = "/";
		int mode = 0;
		long size = mgmt.getObjectSize( bucketName, key, mode );
		assertEquals( 10, size );
		System.out.println( size );
	}
}
