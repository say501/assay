package performance;

import performance.s3.CreateBucketPerfTest;
import performance.s3.ListObjectPerfTest;
import performance.s3.UploadObjectPerfTest;
import performance.util.S3TestUtil;

public class TestMain {
	public static void main (String[]args ){
		if(args[0].equals("CreateBucket")){
			CreateBucketPerfTest.main(new String[]{args[1], args[2], args[3]});
		}else if(args[0].equals("UploadObject")){
			UploadObjectPerfTest.main(new String[]{args[1], args[2], args[3]});
		}else if(args[0].equals("ListObject")){
			ListObjectPerfTest.main(new String[]{args[1], args[2], args[3]});
		}else if(args[0].equals("ClearAllBucket")){
			S3TestUtil.clearAllBucket();
		}else{
			System.out.println("Incorrect input format" + System.nanoTime());
			System.exit(0);
		}
	}
}
