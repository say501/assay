package com.sk.services.css.model;

import com.amazonaws.AmazonWebServiceRequest;

public class ExtClientRequest extends AmazonWebServiceRequest {
	private String bucketName;
	private String key;
	private String metadataKey;
	private String sourceBucketName;
	private String destinationBucketName;
	private String destinationKey;
	private Publishing publishing;

	public ExtClientRequest(String bucketName, String key) {
		this.bucketName = bucketName;
		this.key = key;
	}

	public String getBucketName() {
		return bucketName;
	}

	public String getKey() {
		return key;
	}

	public String getMetadataKey() {
		return metadataKey;
	}

	public String getSourceBucketName() {
		return sourceBucketName;
	}

	public String getDestinationBucketName() {
		return destinationBucketName;
	}

	public String getDestinationKey() {
		return destinationKey;
	}

	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setMetadataKey(String metadataKey) {
		this.metadataKey = metadataKey;
	}

	public void setSourceBucketName(String sourceBucketName) {
		this.sourceBucketName = sourceBucketName;
	}

	public void setDestinationBucketName(String destinationBucketName) {
		this.destinationBucketName = destinationBucketName;
	}

	public void setDestinationKey(String destinationKey) {
		this.destinationKey = destinationKey;
	}

	public Publishing getPublishing() {
		return publishing;
	}

	public void setPublishing(Publishing publishing) {
		this.publishing = publishing;
	}

	public ExtClientRequest withMetadataKey(String metadataKey) {
		this.metadataKey = metadataKey;
		return this;
	}

	public ExtClientRequest withSourceBucketName(String sourceBucketName) {
		this.sourceBucketName = sourceBucketName;
		return this;
	}

	public ExtClientRequest withDestinationBucketName(String destinationBucketName) {
		this.destinationBucketName = destinationBucketName;
		return this;
	}

	public ExtClientRequest withDestinationKey(String destinationKey) {
		this.destinationKey = destinationKey;
		return this;
	}
	
	public ExtClientRequest withPublishing(Publishing publishing) {
		this.publishing = publishing;
		return this;
	}
}
