package com.sk.services.css.management.model;

public class ClusterResult {
	private Long count;

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}
}
