/**
 * SK CSS 서비스를 이용하기 위한 데이터 타입 모델링 클래스
 * 
 */
package com.sk.services.css.model;
