package iam;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagement;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagementClient;
import com.amazonaws.services.identitymanagement.model.CreateGroupRequest;
import com.amazonaws.services.identitymanagement.model.CreateGroupResult;
import com.amazonaws.services.identitymanagement.model.DeleteGroupRequest;
import com.amazonaws.services.identitymanagement.model.Group;
import com.amazonaws.services.identitymanagement.model.ListGroupsRequest;
import com.amazonaws.services.identitymanagement.model.ListGroupsResult;

public class GroupTest {
	private final static String accessKey = "AKIAIFFCMOS3ZSOMLD7A";
	private final static String secretKey = "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";

	private final static String accessKeyId = "YANK0APMIDACKO23PEAN";
	private final static String secretAccessKey = "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";
	private final static String devUrl = "iam.skcloud.com";

	private AmazonIdentityManagement iam;
	private final String groupName = "G-20110812142016";
	
	@Before
	public void setUp() throws Exception {
		iam = new AmazonIdentityManagementClient( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		iam.setEndpoint( devUrl );
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAIM_ListGroups() {
		AmazonIdentityManagement aim = new AmazonIdentityManagementClient( new BasicAWSCredentials( accessKey, secretKey ) );
		ListGroupsRequest request = new ListGroupsRequest();
		request.setPathPrefix( "/" );

		ListGroupsResult listGroups = aim.listGroups( request );
		for (Group group : listGroups.getGroups()) {
			System.out.println( "Group Name ==> " + group.getGroupName() );
			System.out.println( "Group Id ==> " + group.getGroupId() );
			System.out.println( "Group Path ==> " + group.getPath() );
			System.out.println( "Group Arn ==> " + group.getArn() );
			System.out.println( "Group Create Date ==> " + group.getCreateDate() );
			System.out.println();
		}
	}

	@Test
	public void testIAM_ListGroups() {
		ListGroupsRequest request = new ListGroupsRequest();
		request.setPathPrefix( "/" );

		ListGroupsResult listGroups = iam.listGroups( request );
		for (Group group : listGroups.getGroups()) {
			System.out.println( group.toString() );
		}
	}

	@Test
	public void testIAM_CreateGroup() {
		CreateGroupRequest createGroupRequest = new CreateGroupRequest();
		// String groupName = "G-" + getName();
		String groupName = "G-20110819163722"; //"G-" + getName();
		createGroupRequest.setGroupName( groupName );
		createGroupRequest.setPath( "/" );

		CreateGroupResult createGroup = iam.createGroup( createGroupRequest );
		Group group = createGroup.getGroup();

		Assert.assertEquals( groupName, group.getGroupName() );
		System.out.println( group.getGroupId() );
	}


	public static String getName() {
		SimpleDateFormat formatter = new SimpleDateFormat( "yyyyMMddHHmmss", Locale.KOREA );
		return formatter.format( new Date() );
	}

	@Test
	public void test_DeleteGroup() throws Exception {
		DeleteGroupRequest request = new DeleteGroupRequest();
		request.setRequestCredentials( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		request.setGroupName( "G-20110824174038" );
		
		iam.deleteGroup( request  );
	}
}
