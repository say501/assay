package performance.s3;

import junit.framework.Test;
import junit.framework.TestResult;
import performance.S3PerfTestSuite;
import performance.util.S3TestUtil;

public class UploadObjectPerfTest {

	/**
	 * Creates object for the specified amount time and writes output to C:\testS3. Objects are created in a single bucket
	 * @param users
	 * @param iterations
	 * @param intervalTime Delay between the addition of each concurrent user
	 */
	public static Test testUploadObject(int users, int iterations, int intervalTime){
		return S3PerfTestSuite.responseTimeUnderLoadTestSuite(UploadObject.class, users, iterations, intervalTime, 5000000);
	}
		
	public static void main(String[] args) {
		int users = 0, iterations = 0, intervalTime = 0;		
		users = Integer.parseInt(args[0]);
		iterations = Integer.parseInt(args[1]);	
		intervalTime = Integer.parseInt(args[2]);
		
		StringBuffer result = new StringBuffer("maxUser "+users+" iteration "+iterations+" timerConstant "+intervalTime+"\n");
		try{
			long testStart = System.currentTimeMillis();
			TestResult tr = junit.textui.TestRunner.run( testUploadObject(users, iterations, intervalTime) );
			
			long testEnd = System.currentTimeMillis();
			
			String success = (tr.errorCount() + tr.failureCount() == 0) ? "SUCCESS":"FAIL";
			
			// write results
			result.append("TestStart: " + S3TestUtil.getTimeStamp("yyyy/MM/dd HH:mm:ss", testStart) 
					+ "\tTestEnd: " + S3TestUtil.getTimeStamp("yyyy/MM/dd HH:mm:ss", testEnd) 
					+ "\t" + success + "\tErrors: " + (tr.failureCount()+tr.errorCount()) + "\n");
			
			System.out.println(result);
		
		}catch(Exception e){
			System.out.println(e.getMessage());
		}	
	}	
}
