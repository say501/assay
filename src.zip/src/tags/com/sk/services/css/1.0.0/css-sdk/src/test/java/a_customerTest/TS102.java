package a_customerTest;

import java.beans.Encoder;
import java.io.File;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectMetadataRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.ListMultipartUploadsRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.Region;
import com.sk.services.css.AmazonS3ClientExt;
import com.sk.services.css.AmazonS3Ext;
import com.sk.services.css.model.Publishing;
import com.sk.services.css.sample.BucketSample;
import com.sk.services.css.sample.CredentialSample;
import com.sk.services.css.sample.ObjectSample;

public class TS102
{
	private final String accessKeyId = "7B61B4608BC71CF8GGC2";//"VIW1P9YYWSNMD6DVK9YP";
	private final String secretAccessKey = "6+fVCoCxiii/cR/oOokeNrafvcPEOSKT9CLkpgB/";//"7p+BhenfAeP8QjUIbUP3ozAYMcWIBr92+jV04kj+";
	private String endpoint = "http://s3.skcloud.com";
	
	private AmazonS3 s3;
	private AmazonS3Ext client;
	
	@Before
	public void initialize ()
	{
		// 사용자 인증 설정
		CredentialSample cr = new CredentialSample (this.accessKeyId, this.secretAccessKey);
		
		// 인증된 AmazonS3 인스턴스를 얻어온다.
		this.s3 = cr.getAuthenticatedInstance ();
		
		// 목적지 서버 설정
		this.s3.setEndpoint (this.endpoint);
	}
	
	@Before
	public void initializeExt () 
	{
		this.client = new AmazonS3ClientExt (new BasicAWSCredentials (this.accessKeyId, this.secretAccessKey));
		this.client.setEndpoint (this.endpoint);
	}
	@Test
	public void TS102_TC_01_Test()  throws Exception {
		this.TS102_TC_01();
	}
	@Test
	public void TS102_TC_02_Test()  throws Exception {
		this.TS102_TC_02();
	}
	@Test
	public void TS102_TC_03_Test()  throws Exception {
		this.TS102_TC_03();
	}
	@Test
	public void TS102_TC_04_Test()  throws Exception {
		this.TS102_TC_04();
	}
	@Test
	public void TS102_TC_05_Test()  throws Exception {
		this.TS102_TC_05();
	}
	@Test
	public void TS102_TC_06_Test()  throws Exception {
		this.TS102_TC_06();
	}
	@Test
	public void TS102_TC_07_Test()  throws Exception { //결과값 필요
		this.TS102_TC_07();
	}
	@Test
	public void TS102_TC_08_and_09Test()  throws Exception { //결과값 필요
		this.TS102_TC_08_and_09();
	}
	@Test
	public void TS102_TC_10_Test()  throws Exception {
		this.TS102_TC_10();
	}
	
	@Test
	public void TS102_TC_11_Test()  throws Exception {
		this.TS102_TC_11();
	}
	
	@Test
	public void TS102_TC_12_Test()  throws Exception { //junit fail결과값 필요
		this.TS102_TC_12();
	}
	
	@Test
	public void TS102_TC_13_Test()  throws Exception { 
		this.TS102_TC_13();
	}
	
	@Test
	public void TS102_TC_14_Test()  throws Exception {
		this.TS102_TC_14();
	}
	@Test
	public void TS102_TC_15_Test()  throws Exception { 
		this.TS102_TC_15();
	}
	
	@Test
	public void TS102_TC_16_Test()  throws Exception { 
		this.TS102_TC_16();
	}
	
	@Test
	public void TS102_TC_17_Test()  throws Exception { //J-unit 통과못함
		this.TS102_TC_17();
	}
	
	@Test
	public void TS102_TC_18_Test()  throws Exception { //결과값 필요
		this.TS102_TC_18();
	}
	@Test
	public void TS102_TC_19_Test()  throws Exception {
		this.TS102_TC_19();
	}
	
	@Test
	public void TS102_TC_20_Test()  throws Exception {
		this.TS102_TC_20();
	}
	@Test
	public void listBucket ()
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.printBucketList ();
	}
	

	@Test
	public void TS102_TC_01 () // createBucket ()
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.createBucket (new CreateBucketRequest ("test", Region.AP_Tokyo)); 
		
	}
	@Test
	public void TS102_TC_02 () // createDirectory ()
	{
		// Success.
		this.client.createDirectory ("newbucket", "abcd");
		
		// Failed.
		//this.client.createDirectory ("bucket-502", "aaaaaa");
	}
	@Test
	public void TS102_TC_03 () // uploadObject () 
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Create user metadata
		ObjectMetadata metadata = new ObjectMetadata ();
		metadata.addUserMetadata ("a", "hh");
		metadata.addUserMetadata ("d", "1111");
		
		// Success. ////////////////////////////////////////////////////////////////////////////////////////////
		// Create request for uploading object
		PutObjectRequest req = new PutObjectRequest ("newbucket", "movie.sql", new File ("D://", "test.txt"));
		req.setMetadata (metadata);

		// Upload object
		objectSample.uploadObjectByPut (req);
		////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		// Failed. /////////////////////////////////////////////////////////////////////////////////////////////
		// Create request for uploading object
		req = new PutObjectRequest ("noexist", "test.txt", new File ("D://", "test.txt"));
		req.setMetadata (metadata);

		// Upload object
		objectSample.uploadObjectByPut (req);
		////////////////////////////////////////////////////////////////////////////////////////////////////////
	}
	@Test
	public void TS102_TC_04 () // infoBucket () // 버킷 정보 확인  //(추가 요망)
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.printBucketInfo ("test");
		
		// Added by 501
		System.out.println (this.s3.getBucketPolicy ("test").getPolicyText());
	}
	
	@Test
	public void TS102_TC_05 () // getBucketLocation // 버킷의 위치 정보 확인(추가 요망)
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.printBucketLocation ("newbucket");
	}
	@Test
	public void TS102_TC_06 () // getObjectAcl () 
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Absolute success.
		// This method is not supported. So result code is always 200 OK.
		objectSample.getObjectAcl ("newbucket", "movie.sql");
	}
	
	@Test
	public void TS102_TC_07 () // deleteBucket () 
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.deleteBucket ("test");
	}

	@Test
	public void TS102_TC_08_and_09 () //deleteObject ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.deleteObject (new DeleteObjectRequest ("langju-bucket", "folder/langju-folder/1.txt"));
		
		// Failed.
		//objectSample.deleteObject (new DeleteObjectRequest ("noexist", "a/version.ini"));
	}

	@Test
	public void TS102_TC_10 () // getObject () 
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.printObjectInfo (new GetObjectRequest ("newbucket", "movie.sql"));
		
		// Failed.
		//objectSample.printObjectInfo (new GetObjectRequest ("bucket-502", "1.txt"));
	}
	
	@Test
	public void TS102_TC_11 () // getMetadata () 
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.printObjectMetadata (new GetObjectMetadataRequest ("langju-bucket", "folder/langju-folder/1.zip"));
		
		// Failed.
		//objectSample.printObjectMetadata (new GetObjectMetadataRequest ("bucket-502", "noexist.file"));
	}

	@Test
	public void TS102_TC_12 () // setObjectMetadata ()
	{
		// Make user metadata.
		Map<String, Object> metadata = new HashMap<String, Object> ();
		//metadata.put ("1", "one");
		//metadata.put ("2", "two");
		//metadata.put ("3", "ldaskjflasjdlfjlsajdflaj");
		//metadata.put ("4", "four");
		//metadata.put ("5", "five");
		
		String str = java.net.URLEncoder.encode ("한글");
		metadata.put ("name", str);
		metadata.put ("4", "s4");
		metadata.put ("5", "s5");

		// Set user metadata.
		// Success.
		this.client.setObjectMetadata ("langju-bucket", "folder/langju-folder/1.zip", metadata);
		// Failed.
		//this.client.setObjectMetadata ("bucket-502", "noexist", metadata);
	}
	
	@Test
	public void TS102_TC_13 () // deleteObjectMetadata () 
	{
		// Success.
		this.client.deleteObjectMetadata ("langju-bucket", "folder/langju-folder/1.zip", "4");
		
		// Failed.
		//this.client.deleteObjectMetadata ("bucket-502", "noexist", "1");
	}
	
	@Test
	public void TS102_TC_14 () // listObject ()
	{
		ObjectSample objectSample = new ObjectSample (s3);

		// Success.
		objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("langju-bucket"));//.withPrefix("folder/langju-folder/"));

		// Failed.
		//objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("notexist"));
	}
	
	@Test
	public void TS102_TC_15 () // listObjectWithPrefix () 
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("newbucket").withPrefix ("aaaaaa/"));

		// Failed.
		//objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("bucket-502").withPrefix ("noexist/"));
	}
	
	@Test
	public void TS102_TC_16 () // listMultipartUpload ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		objectSample.printMultipartUploadList (new ListMultipartUploadsRequest ("langju-bucket"));
	}
	
	@Test
	public void TS102_TC_17 () // uploadMultipart ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		objectSample.uploadObjectByMultipart (new InitiateMultipartUploadRequest ("langju-bucket", "1.zip"));
	}
	
	@Test
	public void TS102_TC_18 () //  abortMultipartUpload () 
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.abortMultipartUpload (new AbortMultipartUploadRequest ("langju-bucket", "1.zip", "g2RRBpeyl3w8KCG0zJ7tQ5DhS1A="));
		
		// Failed.
		//objectSample.abortMultipartUpload (new AbortMultipartUploadRequest ("newbucket", "restlet-1.1.10.zip", "noexistid"));
	}
	
	@Test
	public void TS102_TC_19 () // putObjectPublishing () 
	{
		// Success.
		Publishing result = this.client.putPublishing ("langju-bucket", "1.zip");
		System.out.println (result.toString ());
		
		// Success.
		//result = this.client.putPublishing ("newbucket", "movie.sql");
		//System.out.println (result.toString ());
	}
	
	@Test
	public void TS102_TC_20() // putObjectPublishingUsingExpiredate ()
	{		
		long after7day = 1000 * 60 * 2;//1000 * 3600 * 24 * 7;
		Timestamp expireDate = new Timestamp (new Date ().getTime () + after7day);

		Publishing pub = new Publishing ();
		pub.setGeneratedUri ("GeneralURI");
		pub.setExpireDate (expireDate);

		// Success.
		Publishing result = this.client.putPublishing ("langju-bucket", "1.zip", pub);
		System.out.println (result.toString ());
		
		// Failed.
		//result = this.client.putPublishing ("newbucket", "noexist", pub);
		//System.out.println (result.toString ());
	}
	
	public static void main (String[] args)
	{
		File file = new File ("d:\\test", "1.zip");
		System.out.println (file.exists());
	}
}
