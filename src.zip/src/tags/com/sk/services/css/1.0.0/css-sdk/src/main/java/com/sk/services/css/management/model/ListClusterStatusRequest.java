package com.sk.services.css.management.model;

import com.amazonaws.AmazonWebServiceRequest;

public class ListClusterStatusRequest extends AmazonWebServiceRequest {
	private String volumeName;

	public String getVolumeName() {
		return volumeName;
	}

	public void setVolumeName(String volumeName) {
		this.volumeName = volumeName;
	}

	public ListClusterStatusRequest(String volumeName) {
		this.volumeName = volumeName;
	}

	public ListClusterStatusRequest() {
	}
}
