package com.sk.services.css.management.model;

import com.amazonaws.AmazonWebServiceRequest;

public class ListClusterRequest extends AmazonWebServiceRequest {
	public ListClusterRequest() {
	}
}
