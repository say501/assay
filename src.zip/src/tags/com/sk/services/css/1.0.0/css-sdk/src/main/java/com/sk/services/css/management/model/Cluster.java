package com.sk.services.css.management.model;

/**
 * <p>
 * T-FS 클러스터 정보
 * </p>
 * 
 */
public class Cluster {
	String name;
	String ipAddress;
	boolean enabled;
	String description;

	public Cluster() {

	}

	/**
	 * <p>
	 * 클러스터 이름을 가져온다.
	 * </p>
	 * 
	 * @return 클러스터 이름
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * <p>
	 * 클러스터 이름을 설정한다.
	 * </p>
	 * 
	 * @param name
	 *            클러스터 이름
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * <p>
	 * 클러스터의 네트워크 상 위치 주소를 가져온다.
	 * </p>
	 * 
	 * @return 클러스터가 위치한 네트워크 아이피 주소
	 */
	public String getIpAddress() {
		return this.ipAddress;
	}

	/**
	 * <p>
	 * 클러스터의 네트워크 상 위치 주소를 설정한다.
	 * </p>
	 * 
	 * @param ipAddress
	 *            아이피 주소 (Only Ipv4)
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * <p>
	 * 클러스터의 현재 상태를 가져온다.
	 * </p>
	 * <ul>
	 * <li>true : 사용이 가능한 상태</li>
	 * <li>false : 사용이 불가능한 상태</li>
	 * </ul>
	 * 
	 * @return 현재 상태
	 */
	public boolean getEnabled() {
		return this.enabled;
	}

	/**
	 * <p>
	 * 클러스터의 현재 상태를 설정한다.
	 * </p>
	 * <ul>
	 * <li>true : 사용이 가능한 상태</li>
	 * <li>false : 사용이 불가능한 상태</li>
	 * </ul>
	 * 
	 * @param enabled
	 *            클러스터 상태 설정
	 */
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	/**
	 * <p>
	 * 클러스터 관련 설명을 가져온다.
	 * </p>
	 * 
	 * @return 클러스터 설명
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * <p>
	 * 클러스터 관련 설명을 입력한다.
	 * </p>
	 * 
	 * @param description
	 *            클러스터 설명
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append( "{" );
		sb.append( "Name: " + name + ", " );
		sb.append( "IpAddress: " + ipAddress + ", " );
		sb.append( "Enabled: " + enabled + ", " );
		sb.append( "Description: " + description + ", " );
		sb.append( "}" );
		return sb.toString();
	}
}
