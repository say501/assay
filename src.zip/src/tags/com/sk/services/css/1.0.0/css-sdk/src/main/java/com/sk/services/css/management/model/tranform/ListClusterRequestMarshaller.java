package com.sk.services.css.management.model.tranform;

import com.amazonaws.DefaultRequest;
import com.amazonaws.Request;
import com.amazonaws.transform.Marshaller;
import com.sk.services.css.management.model.ListClusterRequest;

public class ListClusterRequestMarshaller implements Marshaller<Request<ListClusterRequest>, ListClusterRequest> {
	@Override
	public Request<ListClusterRequest> marshall(ListClusterRequest listClusterRequest) throws Exception {
		Request<ListClusterRequest> request = new DefaultRequest<ListClusterRequest>( listClusterRequest, "CSSManagement" );
		request.addParameter( "Action", "ListClusters" );
		request.addParameter( "Version", "2011-08-16" );

		return request;
	}

}
