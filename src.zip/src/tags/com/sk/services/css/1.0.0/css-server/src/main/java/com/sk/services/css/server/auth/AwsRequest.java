package com.sk.services.css.server.auth;

import java.io.InputStream;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.restlet.data.Form;

import com.amazonaws.AmazonWebServiceRequest;
import com.amazonaws.Request;
import com.amazonaws.http.HttpMethodName;

public class AwsRequest implements Request<AwsRequest>
{
	private String bucketName;
	private String resourcePath;
	
	private Map<String, String> headersMap = null;
	private Map<String, String> parametersMap = new HashMap<String, String> ();
	
	public AwsRequest (Form headers)
	{
		this.headersMap = headers.getValuesMap ();
		
		// Get bucket name.
		this.bucketName = headers.getFirstValue ("host");
		String[] cname = this.bucketName.split ("[.]");
		if (cname.length > 3)
		{
			this.bucketName = "/" + cname[0];
		}
		else
		{
			this.bucketName = "";
		}
	}
	
	public AwsRequest (Form headers, Form parameters)
	{
		this (headers);
		this.parametersMap = parameters.getValuesMap ();
	}
	
	@Override
	public void addHeader (String name, String value)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<String, String> getHeaders ()
	{
		return this.headersMap;
	}

	@Override
	public void setResourcePath (String path)
	{
		this.resourcePath = this.bucketName + path;
	}

	@Override
	public String getResourcePath ()
	{
		return this.resourcePath;
	}

	@Override
	public void addParameter (String name, String value)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public Request<AwsRequest> withParameter (String name, String value)
	{
		this.parametersMap.put (name, value);
		return this;
	}

	@Override
	public Map<String, String> getParameters ()
	{
		return this.parametersMap;
	}

	@Override
	public URI getEndpoint ()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setEndpoint (URI endpoint)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public HttpMethodName getHttpMethod ()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setHttpMethod (HttpMethodName httpMethod)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public InputStream getContent ()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setContent (InputStream content)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getServiceName ()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AmazonWebServiceRequest getOriginalRequest ()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
