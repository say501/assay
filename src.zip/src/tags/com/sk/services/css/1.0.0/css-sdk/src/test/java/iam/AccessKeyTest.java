package iam;

import static org.junit.Assert.assertNotNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagement;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagementClient;
import com.amazonaws.services.identitymanagement.model.AccessKey;
import com.amazonaws.services.identitymanagement.model.AccessKeyMetadata;
import com.amazonaws.services.identitymanagement.model.CreateAccessKeyRequest;
import com.amazonaws.services.identitymanagement.model.CreateAccessKeyResult;
import com.amazonaws.services.identitymanagement.model.DeleteAccessKeyRequest;
import com.amazonaws.services.identitymanagement.model.ListAccessKeysRequest;
import com.amazonaws.services.identitymanagement.model.ListAccessKeysResult;

public class AccessKeyTest {
	private final static String accessKey = "AKIAIFFCMOS3ZSOMLD7A";
	private final static String secretKey = "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";

	private final static String accessKeyId = "YANK0APMIDACKO23PEAN";
	private final static String secretAccessKey = "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";
	private final static String devUrl = "iam.skcloud.com";

	private AmazonIdentityManagement iam;

	@Before
	public void setUp() throws Exception {
		iam = new AmazonIdentityManagementClient( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		iam.setEndpoint( devUrl );
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAIM_AccessKeyList() throws Exception {
		AmazonIdentityManagement aim = new AmazonIdentityManagementClient( new BasicAWSCredentials( accessKey, secretKey ) );

		ListAccessKeysRequest request = new ListAccessKeysRequest();
		request.setUserName( "ryan.ggg.ahn" );
		ListAccessKeysResult listKeys = aim.listAccessKeys( request );

		for (AccessKeyMetadata meta : listKeys.getAccessKeyMetadata()) {
			System.out.println( meta.toString() );
		}
	}

	@Test
	public void test_AccessKeyList() throws Exception {
		ListAccessKeysRequest request = new ListAccessKeysRequest();
		request.setUserName( "U-20110824174235" );
		ListAccessKeysResult listKeys = iam.listAccessKeys( request );

		for (AccessKeyMetadata meta : listKeys.getAccessKeyMetadata()) {
			System.out.println( meta.toString() );
		}
	}

	@Test
	public void test_AccessKeyIdCreate() throws Exception {

		CreateAccessKeyRequest request = new CreateAccessKeyRequest();
		request.setUserName( "U-20110824174235" );

		CreateAccessKeyResult createAccessKey = iam.createAccessKey( request );
		AccessKey accessKey = createAccessKey.getAccessKey();
		assertNotNull( accessKey );
		System.out.println( accessKey.toString() );
	}
	
	@Test
	public void test_AccessKeyIdCreate_By_UserAccount() throws Exception {
		iam = new AmazonIdentityManagementClient( new BasicAWSCredentials( "FAKMGADK16VCCETN2P25", "RXlSuF8AYznpQGYhqaFolw1Z680/LbC7znupAQMX" ) );
		iam.setEndpoint( devUrl );
		
		CreateAccessKeyRequest request = new CreateAccessKeyRequest();
		request.setUserName( "U-20110821201003" );
		
		CreateAccessKeyResult createAccessKey = iam.createAccessKey( request );
		AccessKey accessKey = createAccessKey.getAccessKey();
		assertNotNull( accessKey );
		System.out.println( accessKey.toString() );
	}

	public static String getName() {
		SimpleDateFormat formatter = new SimpleDateFormat( "yyyyMMddHHmmss", Locale.KOREA );
		return formatter.format( new Date() );
	}

	@Test
	public void test_AccessKeyIdDelete() throws Exception {
		DeleteAccessKeyRequest request = new DeleteAccessKeyRequest();
		request.setUserName( "U-20110824174235" );
		request.setAccessKeyId( "F72E0EGF28664D9643DD" );

		iam.deleteAccessKey( request );
	}
}
