package com.sk.services.css.management.model.tranform;

import com.amazonaws.DefaultRequest;
import com.amazonaws.Request;
import com.amazonaws.util.StringUtils;
import com.sk.services.css.management.model.ClusterRequest;

public class ClusterRequestMarshaller {
	public Request<ClusterRequest> marshall(ClusterRequest clusterRequest, String action) {
		Request<ClusterRequest> request = new DefaultRequest<ClusterRequest>( clusterRequest, "CSSManagement" );
		request.addParameter( "Action", action );
		request.addParameter( "Version", "2011-08-16" );

		if (clusterRequest != null) {
			if (clusterRequest.getVolumeName() != null) {
				request.addParameter( "VolumeName", StringUtils.fromString( clusterRequest.getVolumeName() ) );
			}
		}
		if (clusterRequest != null) {
			if (clusterRequest.getBucketName() != null) {
				request.addParameter( "BucketName", StringUtils.fromString( clusterRequest.getBucketName() ) );
			}
		}
		if (clusterRequest != null) {
			if (clusterRequest.getKey() != null) {
				request.addParameter( "Key", StringUtils.fromString( clusterRequest.getKey() ) );
			}
		}
		if (clusterRequest != null) {
			if (clusterRequest.getMode() != null) {
				request.addParameter( "Mode", StringUtils.fromString( clusterRequest.getMode() ) );
			}
		}
		if (clusterRequest != null) {
			if (clusterRequest.getType() != null) {
				request.addParameter( "Type", StringUtils.fromString( clusterRequest.getType() ) );
			}
		}
		

		return request;
	}
}
