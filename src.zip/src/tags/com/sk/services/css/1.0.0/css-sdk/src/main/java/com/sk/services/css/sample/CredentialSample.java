package com.sk.services.css.sample;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;

/**
 * <p>
 * Amazon S3 사용자 인증 예제 코드.
 * </p>
 *
 */
public class CredentialSample
{
	String accessKeyId;
	String secretAccessKey;
	
	/**
	 * AmazonS3 인터페이스
	 */
	static AmazonS3 s3;
	
	/**
	 * <p>
	 * Amazon S3 사용자 인증 인스턴스를 얻어온다.
	 * </p>
	 * <p>
	 * 기본 생성자 호출없이 인스턴스를 요청했을 경우 사용자 인증에 필요한 AccessKeyId와 SecretAccessKey 값을 설정할 수 없다. 
	 * 따라서 사용자 AccessKeyId와 SecretAccessKey를 이용해 기본 생성자를 호출한 후 이 메소드를 호출해야만 한다.
	 * </p>
	 * 
	 * @return	AmazonS3 사용자 인증 인스턴스.
	 */
	public AmazonS3 getAuthenticatedInstance ()
	{
		if (s3 == null)
		{
			s3 = new AmazonS3Client (new BasicAWSCredentials (this.accessKeyId, this.secretAccessKey)); 
			return s3;
		}
		
		return s3;
	}
	
	/**
	 * <p>
	 * CredentialSample 기본 생성자.
	 * </p>
	 * 
	 * @param 	accessKeyId 사용자 AccessKeyId 값.
	 * @param 	secretAccessKey 사용자 SecretAccessKey 값.
	 */
	public CredentialSample (String accessKeyId, String secretAccessKey)
	{
		this.accessKeyId = accessKeyId;
		this.secretAccessKey = secretAccessKey;
	}
}
