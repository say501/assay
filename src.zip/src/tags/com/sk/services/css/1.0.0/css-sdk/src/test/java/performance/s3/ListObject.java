package performance.s3;

import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import performance.S3Test;
import performance.util.S3TestUtil;

import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class ListObject extends S3Test {
	
	static final Log log = LogFactory.getLog (ListObject.class);
	/**
	 * Test if listObjects() pulls correctly with 100,000 objects
	 * @throws Exception
	 */
	@Test
	public void testListObject() throws Exception {
		Random r = new Random();
		String bucketName = "bucket-" + S3TestUtil.formatBucketNumber(r.nextInt(1000), 4);
		ObjectListing oList = s3.listObjects(bucketName);
		//System.out.println(oList.getObjectSummaries().size() + " objects in " + bucketName);
	}
	
}
