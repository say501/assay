package com.sk.services.css.management.model.tranform;

import javax.xml.stream.events.XMLEvent;

import com.amazonaws.transform.SimpleTypeStaxUnmarshallers.StringStaxUnmarshaller;
import com.amazonaws.transform.StaxUnmarshallerContext;
import com.amazonaws.transform.Unmarshaller;
import com.sk.services.css.management.model.ClusterResult;

public class ClusterResultStaxUnmarshaller implements Unmarshaller<ClusterResult, StaxUnmarshallerContext> {

	@Override
	public ClusterResult unmarshall(StaxUnmarshallerContext context) throws Exception {
		ClusterResult clusterResult = new ClusterResult();

		int originalDepth = context.getCurrentDepth();
		int targetDepth = originalDepth + 1;

		if (context.isStartOfDocument())
			targetDepth += 2;

		while (true) {
			XMLEvent xmlEvent = context.nextEvent();
			if (xmlEvent.isEndDocument())
				return clusterResult;

			if (xmlEvent.isAttribute() || xmlEvent.isStartElement()) {
				if (context.testExpression( "Count", targetDepth )) {
					clusterResult.setCount( Long.valueOf( StringStaxUnmarshaller.getInstance().unmarshall( context ) ) );
					continue;
				}
				
				if (context.testExpression( "Size", targetDepth )) {
					clusterResult.setCount( Long.valueOf( StringStaxUnmarshaller.getInstance().unmarshall( context ) ) );
					continue;
				}
			} else if (xmlEvent.isEndElement()) {
				if (context.getCurrentDepth() < originalDepth) {
					return clusterResult;
				}
			}
		}
	}

	private static ClusterResultStaxUnmarshaller instance;

	public static ClusterResultStaxUnmarshaller getInstance() {
		if (instance == null)
			instance = new ClusterResultStaxUnmarshaller();
		return instance;
	}

}
