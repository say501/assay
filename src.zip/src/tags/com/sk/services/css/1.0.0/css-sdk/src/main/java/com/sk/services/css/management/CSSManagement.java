package com.sk.services.css.management;

import java.util.List;
import java.util.Map;

import com.sk.services.css.management.exception.CSSException;
import com.sk.services.css.management.model.Cluster;

/**
 * <p>
 * SK CSS 관리 서비스에 엑세스 하기 위한 인터페이스를 제공한다. 
 * </p>
 * SK CSS는 인터넷 환경에서 스토리지 공간을 제공하고, 개발자를 위해 쉽게 웹 확장 기능을 만들 수 있게 디자인 되어 있다. 
 * <p>
 * SK CSS Java SDK는 언제, 어디서든지 웹 환경에서 아무 데이터나 검색하고 보관하는 용도로 사용될 있도록 간단한 인터페이스를 제공한다. 
 * 개발자 누구든 동일하게 SK는  웹 사이트의 글로벌 네트워크로  운용되어 높은 확장성, 신뢰성, 보안성, 속도 그리고 저렴한 인프라를 엑세스할 수 있게 해준다.
 * 이 서비스는 확장에 대한 장점을 확보하는 것과 개발자에게로 돌아가는 이익을 최소화 하는 것이 목적이다. 
 * </p>
 * <p>
 * SK CSS에 대한 더 많은 정보는 <a href="http://doc.micloud.kr/java">http://doc.micloud.kr/java</a>에서 확인할 수 있다. 
 * </p>
 * 
 */
public interface CSSManagement 
{	
	/**
	 * <p>
	 * CSS 관리 서비스를 초기화 한다.
	 * </p>
	 * <p>
	 * 만약 초기화 하지 않고 인터페이스를 사용한다면, Default 설정 값을 이용하여 자동으로 초기화 된다.
	 * </p>
	 * 
	 * @return 	초기화 성공 여부
	 */
	public boolean intialize ();
	
	/** 
	 * <p>
	 * 현재 사용하고 있는 SKT-DFS의 볼륨 목록을 가져온다.
	 * </p>
	 * <ul>
	 * 	<li>볼륨 = SKT-DFS 클러스터 단위</li>
	 * </ul>
	 * 
	 * @return 	현재 가용 중인 볼륨 목록을 반환한다.
	 * @throws 	CSSException
	 * @deprecated {@link listCluster()} 참조
	 */
	public List<String> listVolume () throws CSSException;
	
	/**
	 * <p>
	 * 현재 사용하고 있는 SKT-DFS의 클러스터 목록을 가져온다.
	 * </p>
	 * <ul>
	 * 	<li>SKT-DFS 클러스터 </li>
	 * </ul>
	 * 
	 * @return 	현재 가용 중인 클러스터 목록을 반환한다.
	 * @throws 	CSSException
	 * @throws Exception 
	 * @see		com.sk.services.css.model.Cluster
	 */
	public List<Cluster> listCluster () throws CSSException, Exception;
	
	/**
	 * <p>
	 * 지정한 폴더 내의 오브젝트 개수를 가져온다. 단, 해당 사용자 인증 필요.
	 * </p>
	 * <p>
	 * 만약 key 값을 "/"로 지정하면 해당 클러스터의 오브젝트 총 개수를 가져온다.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 현재 오브젝트 개수를 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 오브젝트 개수를 가져온다(Replica 포함, Trash 미포함).</li>
	 * </ul>
	 * <ul>
	 * 	<li>Headers.KEY_TYPE_FOLDER : 파일의 총 개수를 가져온다.</li>
	 * 	<li>Headers.KEY_TYPE_FILE : 폴더의 총 개수를 가져온다.</li>
	 * </ul>
	 * 
	 * @param 	key 폴더의 절대 경로
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @param 	type [Headers.KEY_TYPE_FOLDER | Headers.KEY_TYPE_FILE]
	 * @return 	지정한 단위의 오브젝트  개수를 반환한다(폴더  포함). 단위는 byte.
	 * @throws 	CSSException
	 * @see 	com.amazonaws.auth.AWSCredentials
	 */
	public long getObjectCount (String key, int mode, int type) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 버킷의 폴더 내의 오브젝트 개수를 가져온다. 단, 해당 사용자 인증 필요.
	 * </p>
	 * <p>
	 * 만약 key 값을 "/"로 지정하면 해당 버킷의 오브젝트 총 개수를 가져온다.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 현재 오브젝트 개수를 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 오브젝트 개수를 가져온다(Replica 포함, Trash 미포함).</li>
	 * </ul>
	 * <ul>
	 * 	<li>Headers.KEY_TYPE_FOLDER : 파일의 총 개수를 가져온다.</li>
	 * 	<li>Headers.KEY_TYPE_FILE : 폴더의 총 개수를 가져온다.</li>
	 * </ul>
	 * 
	 * @param 	bucketName 버킷 이름
	 * @param 	key 폴더의 절대 경로
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @param 	type [Headers.KEY_TYPE_FOLDER | Headers.KEY_TYPE_FILE]
	 * @return 	지정한 단위의 오브젝트  개수를 반환한다(폴더  포함). 단위는 byte.
	 * @throws 	CSSException
	 * @see 	com.amazonaws.auth.AWSCredentials
	 */
	public long getObjectCount (String bucketName, String key, int mode, int type) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 폴더의 사용량을 가져온다. 단, 해당 사용자 인증 필요.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 현재 사용량을 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 사용량 가져온다(Replica 포함, Trash 미포함).</li>
	 * </ul>
	 * 
	 * @param 	key 폴더의 절대 경로
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @return 	지정한 단위의 사용량을 반환한다. 단, 폴더는 크기가 없다. 단위는 byte.
	 * @throws 	CSSException
	 * @see 	com.amazonaws.auth.AWSCredentials
	 * @deprecated
	 */
	@Deprecated
	public long getObjectSize (String key, int mode) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 버킷 내 폴더의 사용량을 가져온다. 단, 해당 사용자 인증 필요.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 현재 사용량을 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 사용량 가져온다(Replica 포함, Trash 미포함).</li>
	 * </ul>
	 * 
	 * @param 	bucketName 버킷 이름
	 * @param 	key 폴더의 절대 경로
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @return 	지정한 단위의 사용량을 반환한다. 단, 폴더는 크기가 없다. 단위는 byte.
	 * @throws 	CSSException
	 * @see 	com.amazonaws.auth.AWSCredentials
	 */
	public long getObjectSize (String bucketName, String key, int mode) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 볼륨 내의 오브젝트 총 개수를 가져온다.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 총 오브젝트 개수를 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 총 오브젝트 개수를 가져온다(Replica 포함, Trash 미포함).</li>
	 * </ul>
	 * <ul>
	 * 	<li>Headers.KEY_TYPE_FOLDER : 파일의 총 개수를 가져온다.</li>
	 * 	<li>Headers.KEY_TYPE_FILE : 폴더의 총 개수를 가져온다.</li>
	 * </ul>
	 * 
	 * @param 	volumeName listVolume()을 통해 얻은 볼륨 이름.
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @param	type [Headers.KEY_TYPE_FOLDER | Headers.KEY_TYPE_FILE]
	 * @return 	지정한  볼륨 내의 오브젝트 총 개수를 반환한다.
	 * @throws 	CSSException
	 * @deprecated {@link getClusterCount(String, int, int)} 참조
	 */
	public long getVolumeCount (String volumeName, int mode, int type) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 클러스터 내의 오브젝트 총 개수를 가져온다.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 총 오브젝트 개수를 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 총 오브젝트 개수를 가져온다(Replica 포함, Trash 미포함).</li>
	 * </ul>
	 * <ul>
	 * 	<li>Headers.KEY_TYPE_FOLDER : 파일의 총 개수를 가져온다.</li>
	 * 	<li>Headers.KEY_TYPE_FILE : 폴더의 총 개수를 가져온다.</li>
	 * </ul>
	 * 
	 * @param 	volumeName listCluster()을 통해 얻은 클러스터 이름.
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @param	type [Headers.KEY_TYPE_FOLDER | Headers.KEY_TYPE_FILE]
	 * @return 	지정한  클러스터 내의 오브젝트 총 개수를 반환한다.
	 * @throws 	CSSException
	 */
	public long getClusterCount (String volumeName, int mode, int type) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 볼륨의 총 사용량을  가져온다.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 현재 사용량을 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 사용량 가져온다(Replica 포함, Trash 미포함).</li>
	 * </ul>
	 * 
	 * @param 	volumeName listCluster()을 통해 얻은 볼륨 이름.
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @return 	지정한  볼륨 내의 오브젝트 총 사용량을 반환한다.
	 * @throws 	CSSException
	 * @deprecated {@link getClusterSize(String, int)} 참조
	 */
	public long getVolumeSize (String volumeName, int mode) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 클러스터의 총 사용량을  가져온다.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 현재 사용량을 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 사용량 가져온다(Replica 포함, Trash 미포함).</li>
	 * </ul>
	 * 
	 * @param 	volumeName listCluster()을 통해 얻은 클러스터 이름.
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @return 	지정한  클러스터 내의 오브젝트 총 사용량을 반환한다.
	 * @throws 	CSSException
	 */
	public long getClusterSize (String volumeName, int mode) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 볼륨의 남은 용량을  가져온다.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 현재 남은 용량을 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 남은 용량 가져온다.</li>
	 * </ul>
	 * 
	 * @param 	volumeName listCluster()을 통해 얻은 볼륨 이름.
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @return	지정한 볼륨의 남은 용량을 반환한다.
	 * @throws 	CSSException
	 * @deprecated {@link getClusterFreeSize(String, int)} 참조
	 */
	public long getVolumeFreeSize (String volumeName, int mode) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 클러스터의 남은 용량을  가져온다.
	 * </p>
	 * <ul>
	 * 	<li>Headers.MODE_USABLE : 사용자 단위에서의 현재 남은 용량을 가져온다.</li>
	 * 	<li>Headers.MODE_PHYSICAL : 물리적 파일 시스템 단위에서 남은 용량 가져온다.</li>
	 * </ul>
	 * 
	 * @param 	volumeName listCluster()을 통해 얻은 클러스터 이름.
	 * @param 	mode [Headers.MODE_USABLE | Headers.MODE_PHYSICAL]
	 * @return	지정한 클러스터의 남은 용량을 반환한다.
	 * @throws 	CSSException
	 */
	public long getClusterFreeSize (String volumeName, int mode) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 볼륨의 현재 상태를 가져온다.
	 * </p>
	 * <p>
	 * 볼륨의 모든 상태를 가져온다. (현재까지의 read/write/delete 수 포함.)
	 * </p>
	 * <p>
	 * 	<table border="1">
	 * 		<tr><td width="150" align="center">NAME</td><td width="200" align="center">VALUE (type of String)</td><td></td></tr>
	 * 		<tr><td>path</td><td></td><td>검색 경로</td></tr>
	 * 		<tr><td>dirs</td><td></td><td>폴더 개수</td></tr>
	 * 		<tr><td>files</td><td></td><td>파일 개수</td></tr>
	 * 		<tr><td>du_used_u</td><td></td><td>사용 용량 (Usable)</td></tr>
	 * 		<tr><td>du_used_p</td><td></td><td>사용 용량 (Physical)</td></tr>
	 * 		<tr><td>du_free_u</td><td></td><td>남은 용량 (Usable)</td></tr>
	 * 		<tr><td>du_free_p</td><td></td><td>남은 용량 (Physical)</td></tr>
	 * 		<tr><td>op_creat</td><td></td><td>폴더 및 파일 생성 개수 (누적)</td></tr>
	 * 		<tr><td>op_unlink</td><td></td><td>폴더 및 파일 삭제 개수 (누적)</td></tr>
	 * 		<tr><td>op_speed</td><td></td><td>현재 트랜잭션 속도 (ms)</td></tr>
	 * 		<tr><td>op_write</td><td></td><td>파일 쓴 개수 (누적)</td></tr>
	 * 		<tr><td>op_read</td><td></td><td>파일 읽은 개수 (누적)</td></tr>
	 * 	</table>
	 * </p>
	 * 
	 * @param 	volumeName volumeName listCluster()을 통해 얻은 볼륨 이름.
	 * @return	볼륨의 상태 항목 전부를 반환한다.
	 * @throws 	CSSException
	 * @deprecated {@link listClusterStatus(String)} 참조
	 */
	public Map<String, String> listVolumeStatus (String volumeName) throws CSSException;
	
	/**
	 * <p>
	 * 지정한 클러스터의 현재 상태를 가져온다.
	 * </p>
	 * <p>
	 * 클러스터의 모든 상태를 가져온다. (현재까지의 read/write/delete 수 포함.)
	 * </p>
	 * <p>
	 * 	<table border="1">
	 * 		<tr><td width="150" align="center">NAME</td><td width="200" align="center">VALUE (type of String)</td><td></td></tr>
	 * 		<tr><td>path</td><td></td><td>검색 경로</td></tr>
	 * 		<tr><td>dirs</td><td></td><td>폴더 개수</td></tr>
	 * 		<tr><td>files</td><td></td><td>파일 개수</td></tr>
	 * 		<tr><td>du_used_u</td><td></td><td>사용 용량 (Usable)</td></tr>
	 * 		<tr><td>du_used_p</td><td></td><td>사용 용량 (Physical)</td></tr>
	 * 		<tr><td>du_free_u</td><td></td><td>남은 용량 (Usable)</td></tr>
	 * 		<tr><td>du_free_p</td><td></td><td>남은 용량 (Physical)</td></tr>
	 * 		<tr><td>op_create</td><td></td><td>폴더 및 파일 생성 개수 (누적)</td></tr>
	 * 		<tr><td>op_unlink</td><td></td><td>폴더 및 파일 삭제 개수 (누적)</td></tr>
	 * 		<tr><td>op_write</td><td></td><td>파일 쓴 개수 (누적)</td></tr>
	 * 		<tr><td>op_read</td><td></td><td>파일 읽은 개수 (누적)</td></tr>
	 * 	</table>
	 * </p>
	 * 
	 * @param 	clusterName clusterName listCluster()을 통해 얻은 클러스터 이름.
	 * @return	클러스터의 상태 항목 전부를 반환한다.
	 * @throws 	CSSException
	 */
	public Map<String, String> listClusterStatus (String clusterName) throws CSSException;

	public void setEndpoint(String endpoint) throws java.lang.IllegalArgumentException;
}
