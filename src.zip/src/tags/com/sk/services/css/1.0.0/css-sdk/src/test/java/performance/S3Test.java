package performance;

import junit.framework.TestCase;

import org.junit.Before;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.sk.services.css.AmazonS3ClientExt;
import com.sk.services.css.AmazonS3Ext;

public abstract class S3Test extends TestCase {

	//U-20110821201031
	private static final String accessKeyId = "2G18C3HG40H8007BH690";
	private static final String secretAccessKey = "IWLHSzYBzX86xSWN1+roY8wcszg6L6nuLsh0UDQv";
	
	//U-20110831180518
	//private static final String accessKeyId = "21HG870984DA52A8260B";
	//private static final String secretAccessKey = "Kb1sjRRCmHA2Nzrnf10Z/0Ca9J59OzC+RobDXoQo";
	
	protected String endpoint = "http://s3.skcloud.com";

	protected AmazonS3 s3;
	protected AmazonS3Ext s3Ext;

	@Before
	public void setUp() throws Exception {
		s3 = new AmazonS3Client(new BasicAWSCredentials(accessKeyId, secretAccessKey));
		s3.setEndpoint(endpoint);
		s3Ext = new AmazonS3ClientExt(new BasicAWSCredentials(accessKeyId, secretAccessKey));
		s3Ext.setEndpoint(endpoint);
	}
}
