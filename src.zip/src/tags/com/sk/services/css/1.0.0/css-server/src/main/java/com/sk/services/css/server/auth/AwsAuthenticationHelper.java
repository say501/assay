package com.sk.services.css.server.auth;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.restlet.Request;
import org.restlet.Response;
import org.restlet.data.ChallengeRequest;
import org.restlet.data.ChallengeResponse;
import org.restlet.data.ChallengeScheme;
import org.restlet.data.Parameter;
import org.restlet.engine.http.header.ChallengeWriter;
import org.restlet.engine.security.AuthenticatorHelper;
import org.restlet.util.Series;

public class AwsAuthenticationHelper extends AuthenticatorHelper
{
	static final Log log = LogFactory.getLog (AwsAuthenticationHelper.class);
	
	public static final ChallengeScheme HTTP_AWS = new ChallengeScheme ("HTTP_AWS", "AWS", "Amazon S3 HTTP authentication"); 
	
	public AwsAuthenticationHelper ()
	{
		super (AwsAuthenticationHelper.HTTP_AWS, true, true);
	}
	
	@Override
	public void parseResponse (ChallengeResponse cr, Request request, Series<Parameter> httpHeaders) 
	{
	}
}