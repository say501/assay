package com.sk.services.css.management.exception;

import java.io.Serializable;

import com.amazonaws.AmazonServiceException;

/**
 * <p>
 * SK CSS 서비스에 대해 Exception을 제공한다.
 * </p>
 * <p>
 * CSS 서비스에 대한 모든 Exception을 제공하며, 확장 Request ID에 엑세스를 제공한다. Request ID는 CSS 서비스의 잘못된 요청에 대한 지원이 필요할 경우 디버깅 정보를 요청할 때 필요하다.
 * </p>
 *
 */
public class CSSException extends AmazonServiceException implements Serializable
{
	private static final long serialVersionUID = 1L;

	/**
	 * <p>
	 * 특정 메세지를 가진 SKCSSException을 구성한다.
	 * </p>
	 * 
	 * @param 	message Exception 발생 원인에 대한 메세지.
	 * @see 	CSSException#CSSException(String message, Exception cause)
	 */
	public CSSException (String message)
	{
		super (message);
	}
	
	/**
	 * <p>
	 * 특정 메세지와 상위 Exception을 가진 SKCSSException을 구성한다.
	 * </p>
	 * 
	 * @param 	message Exception 발생 원인에 대한 메세지. 
	 * @param 	cause Exception이 발생한 상위 Exception 클래스.
	 * @see 	CSSException#CSSException(String message)
	 */
	public CSSException (String message, Exception cause)
	{
		super (message, cause);
	}
	
	/**
	 * <p>
	 * CSS 확장 Request ID를 가져온다.
	 * </p>
	 * <p>
	 * Request ID는 CSS 서비스의 잘못된 요청에 대한 지원이 필요할 경우 디버깅 정보를 요청할 때 필요하다.
	 * </p>
	 * 
	 * @return 확장 Request ID를 반환한다.
	 */
	public String getExceptionRequestId ()
	{
		return "";
	}
	
	/**
	 * <p>
	 * CSS 확장 Request ID를 설정한다.
	 * </p>
	 * 
	 * @param extendedRequestId CSS 확장 Request ID
	 */
	public void setExceptionRequestId (String extendedRequestId)
	{
		
	}
	
	/* (non-Javadoc)
	 * @see com.amazonaws.AmazonServiceException#toString()
	 */
	public String toString ()
	{
		return "";
	}
}
