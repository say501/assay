package performance.s3;

import java.io.File;
import java.util.Random;
import org.junit.Test;
import performance.S3Test;
import performance.util.S3TestUtil;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;

public class UploadObject extends S3Test{

	@Test
	public void testUploadObject() {
		File file = new File (S3TestUtil.LOCAL_DATA_PATH, "test.dat");
		Random r = new Random();
		PutObjectRequest req = new PutObjectRequest(
					"bucket-" + S3TestUtil.formatBucketNumber(r.nextInt(1000), 4),
					S3TestUtil.createObjectName(), 
					file);
		
		// Create user metadata //
		ObjectMetadata metadata = new ObjectMetadata ();
		metadata.addUserMetadata ("key1", "test value 1");
		metadata.addUserMetadata ("key2", "test value 2");
		req.setMetadata (metadata);
		
		// upload
		this.s3.putObject (req);
	}
}
