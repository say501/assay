package com.sk.services.css.management.model;

import java.util.ArrayList;
import java.util.List;

public class ListClusterResult {
	private List<Cluster> clusters;

	public List<Cluster> getClusters() {
		if (clusters == null) {
			clusters = new ArrayList<Cluster>();
		}
		return clusters;
	}

	public void setClusters(List<Cluster> clusters) {
		List<Cluster> clusterCopy = new java.util.ArrayList<Cluster>();
		if (clusters != null) {
			clusterCopy.addAll( clusters );
		}
		this.clusters = clusterCopy;
	}
}
