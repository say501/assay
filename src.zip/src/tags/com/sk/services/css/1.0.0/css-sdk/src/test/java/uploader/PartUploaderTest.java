package uploader;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadResult;
import com.amazonaws.services.s3.model.ListPartsRequest;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.PartListing;
import com.amazonaws.services.s3.model.PartSummary;
import com.amazonaws.services.s3.model.ProgressEvent;
import com.amazonaws.services.s3.model.ProgressListener;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.amazonaws.services.s3.model.UploadPartResult;
import com.sk.services.css.management.CSSManagement;
import com.sk.services.css.management.CSSManagementClient;
import com.sk.services.css.management.exception.CSSException;
import com.sk.services.css.management.model.Cluster;
import com.sk.services.css.sample.CredentialSample;
import com.sk.services.css.sample.ObjectSample;
import com.sk.services.css.sample.Uploader;

public class PartUploaderTest {
	
	// 기본 사용자 정보 (보안키, 인증키)
	private final static String accessKeyId = "AKIAIFFCMOS3ZSOMLD7A";
	private final static String secretAccessKey = "ibsVDba94S/gQ3ekPxsCl2wlW+ydf2bXihHclZDn";
	private final static String devUrl = "http://iam.localhost:8080";
	
	// 사용자 인증 설정
	private final static CredentialSample cr = new CredentialSample (accessKeyId, secretAccessKey);
	private final static AmazonS3 s3 = cr.getAuthenticatedInstance();
	private final static String bucketName = "501";
	private final static String fileName  = "testfile.dmg"; // the testfile shoould be located in /cluster02/uploaderTest 

	private static ObjectSample  objectSample = null;
	private static InitiateMultipartUploadRequest request = null;
	private static InitiateMultipartUploadResult initResult = null;
	private  static String uploadId = null;
	private static UploadPartRequest uploadReq = null;
	private static List<PartETag> partETags = null;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	
		s3.setEndpoint ("http://s3.localhost:8080");		
		
//		objectSample = new ObjectSample (s3);
//		objectSample.uploadObjectByMultipart (new InitiateMultipartUploadRequest ("501", "testfile.dmg"));
		
	    uploadReq = new UploadPartRequest ();
		uploadReq.setProgressListener 
		(
			new ProgressListener ()
			{
				long size = 0;
				
				@Override
				public void progressChanged (ProgressEvent progressEvent)
				{
					this.size += progressEvent.getBytesTransfered ();
					System.out.println (this.size / 1024);
				}
			}
		);
			
		partETags = new ArrayList<PartETag> ();
	}
	

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	
	}
	
	@Before
	public  void Setup()
	{
		request = new InitiateMultipartUploadRequest (bucketName, fileName );
		assertNotNull(request);
		
		initResult = s3.initiateMultipartUpload (request);
		assertNotNull(initResult);
		
		uploadId = initResult.getUploadId ();
		
	}

	@Test
	public void test_initiateMultipartUpload() throws CSSException, Exception {
		
//		objectSample.uploadObjectByMultipart (new InitiateMultipartUploadRequest ("501", "testfile.dmg"));
		request = new InitiateMultipartUploadRequest (bucketName, fileName );
		assertNotNull(request);
		
		initResult = s3.initiateMultipartUpload (request);
		assertNotNull(initResult);
		
		uploadId = initResult.getUploadId ();
		assertNotNull(uploadId);
	}

	@Test
	public void test_UploadParts() {
		
		long partSize = 5 * 1024 * 1024; // initial Size 5MB

		File file = new File ("/cluster02/uploaderTest/", request.getKey ());
		
		List<PartETag> partETags = new ArrayList<PartETag> ();
		
		for (int i=0; !uploadReq.isLastPart (); i++)
		{
			long offset = partSize * i;
			if (partSize >= file.length () - offset)
			{
				partSize = file.length () - offset;
				uploadReq.setLastPart (true);
			}
			
			// Configure upload request model
			uploadReq.setBucketName (request.getBucketName ());
			uploadReq.setKey (request.getKey ());
			uploadReq.setUploadId (uploadId);
			uploadReq.setPartSize (partSize);
			uploadReq.setFileOffset (offset);
			uploadReq.setPartNumber (i + 1);
			uploadReq.setFile (file);
			
			// Upload part
			UploadPartResult uploadPartResult = s3.uploadPart (uploadReq);
			assertNotNull(uploadPartResult.getPartNumber());
		
			partETags.add (new PartETag (i + 1, uploadPartResult.getETag ()));
		}
		
	}

	@Test
	public void test_getPartlist_Of_UploadJobID() {
		
		int i = 0;
		PartListing partListingResult = s3.listParts (new ListPartsRequest (request.getBucketName (), request.getKey (), uploadId));
		
		assertNotNull(partListingResult);
		
		
		assertNotNull( partListingResult.getBucketName() ); 
		
	
		
		for (PartSummary object : partListingResult.getParts ())
		{
			System.out.println (partETags.get (i).getPartNumber () + ". " + partETags.get (i).getETag () + " / " + object.getPartNumber () + ". " + object.getETag ());
			i++;
		}
		System.out.println (partListingResult.getNextPartNumberMarker ());
		
	}

	@Test
	public void test_GetClusterFreeSize() {
		
		assertNotNull(s3.completeMultipartUpload (new CompleteMultipartUploadRequest (request.getBucketName (), request.getKey (), uploadId, partETags)));
		
	}
}
