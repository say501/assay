package com.sk.services.css.management.model.tranform;

import com.amazonaws.DefaultRequest;
import com.amazonaws.Request;
import com.amazonaws.util.StringUtils;
import com.sk.services.css.management.model.ListClusterStatusRequest;

public class ListClusterStatusRequestMarshaller {

	public Request<ListClusterStatusRequest> marshall(ListClusterStatusRequest listClusterStatusRequest) {
		Request<ListClusterStatusRequest> request = new DefaultRequest<ListClusterStatusRequest>( listClusterStatusRequest, "CSSManagement" );
		request.addParameter( "Action", "ListClusterStatus" );
		request.addParameter( "Version", "2011-08-16" );

		if (listClusterStatusRequest != null) {
			if (listClusterStatusRequest.getVolumeName() != null) {
				request.addParameter( "VolumeName", StringUtils.fromString( listClusterStatusRequest.getVolumeName() ) );
			}
		}

		return request;
	}
}
