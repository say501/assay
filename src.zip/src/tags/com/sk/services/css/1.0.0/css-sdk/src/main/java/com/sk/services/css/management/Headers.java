package com.sk.services.css.management;

/**
 * <p>
 * Extended Common SK CSS HTTP Header 값.
 * </p>
 */
public interface Headers
{
	/**
	 * 폴더 구분자
	 */
	public static final int KEY_TYPE_FOLDER = 0;

	/**
	 * 파일 구분자
	 */
	public static final int KEY_TYPE_FILE = 1;
	
	/**
	 * 심볼릭 구분자
	 */
	public static final int KEY_TYPE_SYMBOLIC = 2;
	
	/**
	 * 물리적 장치 단위 모드
	 */
	public static final int MODE_PHYSICAL = 0;
	
	/**
	 * 사용자 단위 모드
	 */
	public static final int MODE_USABLE = 1;
}
