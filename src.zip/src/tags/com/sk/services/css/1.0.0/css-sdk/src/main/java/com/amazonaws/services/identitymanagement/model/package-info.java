
/**
 * Classes modeling the various types represented by AmazonIdentityManagement.
 */
 package com.amazonaws.services.identitymanagement.model;
        