package com.sk.services.css.sample;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.amazonaws.AmazonClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.AccessControlList;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectMetadataRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.Grant;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadResult;
import com.amazonaws.services.s3.model.ListMultipartUploadsRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ListPartsRequest;
import com.amazonaws.services.s3.model.MultipartUpload;
import com.amazonaws.services.s3.model.MultipartUploadListing;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PartListing;
import com.amazonaws.services.s3.model.PartSummary;
import com.amazonaws.services.s3.model.ProgressEvent;
import com.amazonaws.services.s3.model.ProgressListener;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.amazonaws.services.s3.model.UploadPartResult;
import com.amazonaws.services.s3.model.PartETag;

/**
 * <p>
 * Amazon S3 오브젝트 관리 예제 코드.
 * </p>
 *
 */
public class ObjectSample
{
	AmazonS3 s3;
	
	static final Log log = LogFactory.getLog (ObjectSample.class);
	
	/**
	 * <p>
	 * ObjectSample 확장 생성자
	 * </p>
	 * 
	 * @param 	s3 AmazonS3 인터페이스
	 */
	public ObjectSample (AmazonS3 s3)
	{
		this.s3 = s3;
	}
	
	/**
	 * <p>
	 * 오브젝트 목록을 보여준다.
	 * </p>
	 * 
	 * @param 	req ListObjectsRequest 모델
	 */
	public void printObjectList (ListObjectsRequest req)
	{
		try
		{
			ObjectListing objectLists = this.s3.listObjects (req);
			for (S3ObjectSummary object : objectLists.getObjectSummaries ())
			{
				System.out.println (object.getKey () + " : " + 
									object.getSize () + " : " + 
									object.getOwner ().getDisplayName () + " : " + 
									object.getLastModified () + " : " + 
									object.getStorageClass ());
			}
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 지정한 오브젝트 정보를 보여준다.
	 * </p>
	 * 
	 * @param 	req GetObjectRequest 모델
	 */
	public void printObjectInfo (GetObjectRequest req)
	{
		try
		{
			req.setRange (0, 29);
			S3Object object = this.s3.getObject (req);
			InputStream inputStream = object.getObjectContent ();
			int data;
			for (;(data = inputStream.read ()) > -1;)
			{
				System.out.print ((char) data);
			}
			System.out.println ();
			
			System.out.println ("System metadata: " + object.toString ());
			System.out.println ("User metadata: " + object.getObjectMetadata ().getUserMetadata ());
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
		catch (Exception e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 지정한 오브젝트 메타 정보를 보여준다.
	 * </p>
	 * 
	 * @param 	req GetObjectMetadataRequest 모델
	 */
	public void printObjectMetadata (GetObjectMetadataRequest req)
	{
		try
		{
			ObjectMetadata metadata = this.s3.getObjectMetadata (req);
			System.out.println (metadata.getUserMetadata ());
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	public void headObject ()
	{
		try
		{
			
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 오브젝트를 싱글파트로 업로드 한다.
	 * </p>
	 * 
	 * @param 	req PutObjectRequest 모델
	 */
	public void uploadObjectByPut (PutObjectRequest req)
	{
		try
		{
			PutObjectResult result = this.s3.putObject (req);
			System.out.println (result.getETag () + " : " + result.getVersionId ());
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 등록된 멀티파트 업로드 목록 정보를 보여준다. (해당 파트들 모두 포함.)
	 * </p>
	 * 
	 * @param 	req ListMultipartUploadsRequest 모델
	 */
	public void printMultipartUploadList (ListMultipartUploadsRequest req)
	{
		try
		{
			MultipartUploadListing result = this.s3.listMultipartUploads (req);
			for (MultipartUpload object : result.getMultipartUploads ())
			{
				System.out.println (object.getKey () + " : " + object.getOwner ().getDisplayName () + " : " + object.getUploadId ());
				
				// List the parts
				PartListing partListingResult = this.s3.listParts (new ListPartsRequest (req.getBucketName (), object.getKey (), object.getUploadId ()));
				for (PartSummary part : partListingResult.getParts ())
				{
					System.out.println ("\t" + part.getPartNumber () + ". " + part.getETag ());
				}
			}
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 예약된 멀티파트 업로드를 취소한다.
	 * </p>
	 * 
	 * @param 	req AbortMultipartUploadRequest 모델
	 */
	public void abortMultipartUpload (AbortMultipartUploadRequest req)
	{
		try
		{
			this.s3.abortMultipartUpload (req);
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	public void uploadObjectByMultipartByThread (InitiateMultipartUploadRequest req)
	{
		try
		{
			// Initialize proc.
			InitiateMultipartUploadResult result = this.s3.initiateMultipartUpload (req);
			String uploadId = result.getUploadId ();
			
			// Initialize temporary buffer
			List<PartETag> partETags = new ArrayList<PartETag> ();
			
			for (int i=0; true; i++)
			{				
				// Upload proc.
				long partSize = 5 * 1024 * 1024;
				long offset = partSize * i;
				File file = new File ("D:\\[0]Apps\\util", req.getKey ());
				
				// Initialize request
				UploadPartRequest uploadReq = new UploadPartRequest ();
				
				// Check part offset
				if (partSize >= file.length () - offset)
				{
					partSize = file.length () - offset;
					uploadReq.setLastPart (true);
				}
				
				// Configure upload request model
				uploadReq.setBucketName (req.getBucketName ());
				uploadReq.setKey (req.getKey ());
				uploadReq.setUploadId (uploadId);
				uploadReq.setPartSize (partSize);
				uploadReq.setFileOffset (offset);
				uploadReq.setPartNumber (i + 1);
				uploadReq.setFile (file);
				
				// Upload part using multi thread				
				new Uploader (this, uploadReq, partETags).start ();
				
				if (uploadReq.isLastPart ())
				{
					new Thread ()
					{
						long prevSize = 0;
						long prevTime = 0;
						
						public void run ()
						{
							do
							{
								if (Uploader.isFinished ())
								{
									break;
								}
								
								// Get current status data
								long currentSize = Uploader.getTotalSize ();
								long currentTime = System.currentTimeMillis ();
								
								// Printing
								System.out.println ((currentSize - this.prevSize) / (currentTime - this.prevTime) + " KB/s - " + currentSize / 1000);
								
								// Replace data
								prevSize = currentSize;
								prevTime = currentTime;
								
								try {sleep (1000);} catch (InterruptedException e) {;}
								
							}	while (true);
						}
						
					}.start ();
					
					break;
				}
			}
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 오브젝트를 멀티파트로 업로드 한다.
	 * </p>
	 * 
	 * @param 	req InitiateMultipartUploadRequest 모델
	 */
	public void uploadObjectByMultipart (InitiateMultipartUploadRequest req)
	{
		try
		{
			// Initialize proc.
			InitiateMultipartUploadResult result = this.s3.initiateMultipartUpload (req);
			String uploadId = result.getUploadId ();
			
			System.out.println (uploadId);
			
			// Initialize listener
			UploadPartRequest uploadReq = new UploadPartRequest ();
			uploadReq.setProgressListener 
			(
				new ProgressListener ()
				{
					long size = 0;
					
					@Override
					public void progressChanged (ProgressEvent progressEvent)
					{
						this.size += progressEvent.getBytesTransfered ();
						System.out.println (this.size / 1024);
					}
				}
			);
		
			// Upload proc.
			long partSize = 5 * 1024 * 1024;
			File file = new File ("D:\\[0]Apps\\util", req.getKey ());
			List<PartETag> partETags = new ArrayList<PartETag> ();
			for (int i=0; !uploadReq.isLastPart (); i++)
			{
				long offset = partSize * i;
				if (partSize >= file.length () - offset)
				{
					partSize = file.length () - offset;
					uploadReq.setLastPart (true);
				}
				
				// Configure upload request model
				uploadReq.setBucketName (req.getBucketName ());
				uploadReq.setKey (req.getKey ());
				uploadReq.setUploadId (uploadId);
				uploadReq.setPartSize (partSize);
				uploadReq.setFileOffset (offset);
				uploadReq.setPartNumber (i + 1);
				uploadReq.setFile (file);
				
				// Upload part
				UploadPartResult uploadPartResult = this.s3.uploadPart (uploadReq);
				
				// Add etag value of uploaded part
				partETags.add (new PartETag (i + 1, uploadPartResult.getETag ()));
			}
			
			// List the parts
			// This procedure need not for multipart upload procedure
			int i = 0;
			PartListing partListingResult = this.s3.listParts (new ListPartsRequest (req.getBucketName (), req.getKey (), uploadId));
			for (PartSummary object : partListingResult.getParts ())
			{
				System.out.println (partETags.get (i).getPartNumber () + ". " + partETags.get (i).getETag () + " / " + object.getPartNumber () + ". " + object.getETag ());
				i++;
			}
			System.out.println (partListingResult.getNextPartNumberMarker ());
			
			// Complete multipart upload & merge the parts
			this.s3.completeMultipartUpload (new CompleteMultipartUploadRequest (req.getBucketName (), req.getKey (), uploadId, partETags));
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 오브젝트를 삭제한다.
	 * </p>
	 * 
	 * @param 	req DeleteObjectRequest 모델
	 */
	public void deleteObject (DeleteObjectRequest req)
	{
		try
		{
			this.s3.deleteObject (req);
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
	
	/**
	 * <p>
	 * 오브젝트 ACL을 가져온다.
	 * </p>
	 * 
	 * @param 	bucketName 오브젝트가 위치한 버킷 이름
	 * @param 	key 오브젝트 전체 경로
	 */
	public void getObjectAcl (String bucketName, String key)
	{
		try
		{
			AccessControlList accessControlList = this.s3.getObjectAcl (bucketName, key);
			System.out.println (accessControlList.toString ());
			Iterator<Grant> grants = accessControlList.getGrants ().iterator ();
			while (grants.hasNext ())
			{
				Grant grant = grants.next ();
				System.out.println (grant.getGrantee ().getIdentifier ());
				System.out.println (grant.getPermission ().toString ());
			}
		}
		catch (AmazonClientException e)
		{
			log.error (e);
		}
	}
}
