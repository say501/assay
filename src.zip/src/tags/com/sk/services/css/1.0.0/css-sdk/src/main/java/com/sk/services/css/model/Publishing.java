package com.sk.services.css.model;

import java.sql.Timestamp;

/**
 * <p>
 * 오브젝트 공유 정보
 * </p>
 *
 */
public class Publishing
{
	String generatedUri;
	Timestamp expireDate;
	
	public Publishing ()
	{
		
	}
	
	/**
	 * <p>
	 * 생성된 URI를 가져온다.
	 * </p>
	 * 
	 * @return	생성된 URI
	 */
	public String getGeneratedUri ()
	{
		return this.generatedUri;
	}
	
	/**
	 * <p>
	 * 공유 설정할 URI를 설정한다.
	 * </p>
	 * 
	 * @param 	generatedUri 생성된 공유 URI
	 */
	public void setGeneratedUri (String generatedUri)
	{
		this.generatedUri = generatedUri;
	}
	
	/**
	 * <p>
	 * 퍼블리싱된 오브젝트의 만료일자를 가져온다.
	 * </p>
	 * 
	 * @return 만료일자
	 */
	public Timestamp getExpireDate ()
	{
		return expireDate;
	}
	
	/**
	 * <p>
	 * 퍼블리싱된 오브젝트의 만료일자를 설정한다.
	 * </p>
	 * 
	 * @param expireDate 설정할 만료일자
	 */
	public void setExpireDate (Timestamp expireDate)
	{
		this.expireDate = expireDate;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append( "{" );
		sb.append( "GeneratedUri: " + generatedUri + ", " );
		sb.append( "ExpireDate: " + expireDate );
		sb.append( "}" );
		return sb.toString();
	}
	
	
}
