package com.sk.services.css.management.model;

import java.util.HashMap;
import java.util.Map;

public class ListClusterStatusResult {
	private Map<String, String> listClusterStatus;

	public Map<String, String> getListClusterStatus() {
		if (listClusterStatus == null) {
			listClusterStatus = new HashMap<String, String>();
		}
		return listClusterStatus;
	}

	public void setListClusterStatus(Map<String, String> listClusterStatus) {
		Map<String, String> copyMap = new HashMap<String, String>();
		if (listClusterStatus != null) {
			copyMap.putAll( listClusterStatus );
		}
		this.listClusterStatus = copyMap;
	}
}
