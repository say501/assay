package performance;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.ConstantTimer;
import com.clarkware.junitperf.ExampleTestCase;
import com.clarkware.junitperf.LoadTest;
import com.clarkware.junitperf.TimedTest;
import com.clarkware.junitperf.Timer;

public class S3PerfTestSuite {
	
	/**
	 * Decorate a Test as a LoadTest
	 * @param testClass
	 * @param users
	 * @param iterations
	 * @param intervalTime
	 * @return
	 */
	public static Test loadTestSuite(Class testClass, int users, int iterations, int intervalTime) {
		Timer timer = new ConstantTimer(intervalTime);
		JUnit4PefFactory factory = new JUnit4PefFactory(testClass);
		TestSuite testCase = factory.makeTestSuite();
		Test loadTest = new LoadTest(testCase, users, iterations, timer);

		return loadTest;
	}
	
	/**
	 * Decorate a Test as a TimedTest
	 * @param testClass
	 * @param maxElapsedTime
	 * @return
	 */
	public static Test timedTestSuite(Class testClass, long maxElapsedTime) {
		JUnit4PefFactory factory = new JUnit4PefFactory(testClass);
		TestSuite testCase = factory.makeTestSuite();
		Test timedTest = new TimedTest(testCase, maxElapsedTime);

		return timedTest;
	}
	
	/**
	 * Decorate a TimedTest as a LoadTest to measure response time under load.
	 * @param testClass
	 * @param users
	 * @param iterations
	 * @param intervalTime
	 * @param maxElapsedTime
	 * @return
	 */
	public static Test responseTimeUnderLoadTestSuite(Class testClass, int users, int iterations, int intervalTime, long maxElapsedTime){
		Timer timer = new ConstantTimer(intervalTime);
		JUnit4PefFactory factory = new JUnit4PefFactory(testClass);
		TestSuite testCase = factory.makeTestSuite();
		
        Test timedTest = new TimedTest(testCase, maxElapsedTime);
        Test loadTest = new LoadTest(timedTest, users, iterations, timer);
 
        return loadTest;
	 }
	 
	 /**
	  * Decorate a LoadTest as a TimedTest to measure throughput under load
	  * @param testClass
	  * @param users
	  * @param iterations
	  * @param intervalTime
	  * @param maxElapsedTime
	  * @return
	  */
	public static Test throughputUnderLoadTestSuite(Class testClass, int users, int iterations, int intervalTime, long maxElapsedTime) { 
		Timer timer = new ConstantTimer(intervalTime);
		JUnit4PefFactory factory = new JUnit4PefFactory(testClass);
		TestSuite testCase = factory.makeTestSuite();    
	    
		Test loadTest = new LoadTest(testCase, users, iterations, timer);
		Test timedTest = new TimedTest(loadTest, maxElapsedTime);
		
		return timedTest;
	}
}
