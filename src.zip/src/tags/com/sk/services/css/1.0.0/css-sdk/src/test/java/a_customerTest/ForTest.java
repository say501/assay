package a_customerTest;

import java.io.File;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectMetadataRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.ListMultipartUploadsRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.Region;
import com.sk.services.css.AmazonS3ClientExt;
import com.sk.services.css.AmazonS3Ext;
import com.sk.services.css.model.Publishing;
import com.sk.services.css.sample.BucketSample;
import com.sk.services.css.sample.CredentialSample;
import com.sk.services.css.sample.ObjectSample;

public class ForTest
{
	private final String accessKeyId = "WOEZXNYUIHTTZGKAWPRQ";
	private final String secretAccessKey = "wJicfp/hhFYpTN+xZEu70N/TpuMsDjDgnk2MYTzH";
	private String endpoint = "http://newbucket.s3.skcloud.com";
	
	private AmazonS3 s3;
	private AmazonS3Ext client;
	
	TS101_01_to_02 ts101_first = new TS101_01_to_02();
	TS101_03_to_06 ts101_second = new TS101_03_to_06();
	TS102 ts102 = new TS102();
	TS103 ts103 = new TS103();
	TS104 ts104 = new TS104();

	@Before
	public void initialize ()
	{
		// 사용자 인증 설정
		CredentialSample cr = new CredentialSample (this.accessKeyId, this.secretAccessKey);
		
		// 인증된 AmazonS3 인스턴스를 얻어온다.
		this.s3 = cr.getAuthenticatedInstance ();
		
		// 목적지 서버 설정
		this.s3.setEndpoint (this.endpoint);
	}
	
	@Before
	public void initializeExt () 
	{
		this.client = new AmazonS3ClientExt (new BasicAWSCredentials (this.accessKeyId, this.secretAccessKey));
		this.client.setEndpoint (this.endpoint);
	}
	
	/********************************************************************************************
	 * TS101 Test
	 ********************************************************************************************/
	
	@Test
	public void testTS101_01(){
		try {
			ts101_first.TS101_TC_01();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testTS101_02(){
		try {
			ts101_first.TS101_TC_02();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS101_03_to_06(){
		try {
			ts101_second.TS101_TC_03_to_06();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	/********************************************************************************************
	 * TS102 Test
	 ********************************************************************************************/
	@Test
	public void testTS102_01(){
		try {
			ts102.TS102_TC_01();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}		
	
	@Test
	public void testTS102_02(){
		try {
			ts102.TS102_TC_02();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_03(){
		try {
			ts102.TS102_TC_03();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_04(){
		try {
			ts102.TS102_TC_04();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_05(){
		try {
			ts102.TS102_TC_05();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_06(){
		try {
			ts102.TS102_TC_06();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_07(){
		try {
			ts102.TS102_TC_07();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_08_and_09(){
		try {
			ts102.TS102_TC_08_and_09();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_10(){
		try {
			ts102.TS102_TC_10();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_11(){
		try {
			ts102.TS102_TC_11();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_12(){
		try {
			ts102.TS102_TC_12();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_13(){
		try {
			ts102.TS102_TC_13();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	@Test
	public void testTS102_14(){
		try {
			ts102.TS102_TC_14();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	@Test
	public void testTS102_15(){
		try {
			ts102.TS102_TC_15();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	@Test
	public void testTS102_16(){
		try {
			ts102.TS102_TC_16();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	@Test
	public void testTS102_17(){
		try {
			ts102.TS102_TC_17();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	@Test
	public void testTS102_18(){
		try {
			ts102.TS102_TC_18();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	@Test
	public void testTS102_19(){
		try {
			ts102.TS102_TC_19();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	@Test
	public void testTS102_20(){
		try {
			ts102.TS102_TC_20();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	/********************************************************************************************
	 * TS103 Test
	 ********************************************************************************************/
	// TS103에서는 직접적으로 증명할 수 있는 내용이 TC03과 TC06밖에 없음
	@Test
	public void testTS103_03_and_06(){
		try {
			ts103.TS103_TC_03_and_06();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	/********************************************************************************************
	 * TS104 Test
	 ********************************************************************************************/
		// TS104에 대한 Test는 TS104.java에서 직접 실행
	

}
