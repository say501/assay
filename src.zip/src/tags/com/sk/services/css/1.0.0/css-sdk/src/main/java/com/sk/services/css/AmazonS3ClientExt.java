package com.sk.services.css;

import java.util.Map;
import java.util.Map.Entry;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.AmazonWebServiceRequest;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.Request;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.handlers.RequestHandler;
import com.amazonaws.http.DefaultErrorResponseHandler;
import com.amazonaws.http.ExecutionContext;
import com.amazonaws.http.StaxResponseHandler;
import com.amazonaws.services.s3.Headers;
import com.amazonaws.transform.StaxUnmarshallerContext;
import com.amazonaws.transform.Unmarshaller;
import com.sk.services.css.management.exception.CSSException;
import com.sk.services.css.model.ExtClientRequest;
import com.sk.services.css.model.Publishing;
import com.sk.services.css.model.tranform.ExtClientRequestMarshaller;
import com.sk.services.css.model.tranform.ExtClientResultStaxUnmarshaller;

/**
 * <p>
 * 이 클래스는 AmazoneS3Client의 확장 클래스로 추가 API를 갖고 있다.
 * </p>
 * <p>
 * 추가된 API는 오브젝트 이동, 이름 바꾸기 그리고 공유 설정 관련 메소드가 추가되었으며, AmazonS3Client의 모든 기능 또한 포함한다. 
 * 만약 AmazonS3 서비스를 이용하고자 한다면, AmazonS3Client만으로 이용이 가능하지만, SK CSS서비스를 이용하고자 한다면, AmazonS3Ext를 이용하면 추가 기능을
 * 이용할 수 있다. 단, AmazonS3Client를 이용하면 추가 기능(오브젝트 이동, 이름 바꾸기, 공유 설정 등)을 이용할 수가 없다.
 * </p>
 * <p>
 * <blockquote><pre>
 * // Native AmazonS3 Class를 사용할 때 
 * AmazonS3 = new AmazonS3Client ();
 * 
 * // Extended AmazonS3 Class를 사용할 때
 * AmazonS3Ext = new AmazonS3ClientExt ();
 * </pre></blockquote>
 * </p>
 * 
 * @see 	com.amazonaws.services.s3.AmazonS3Client
 *
 */
public class AmazonS3ClientExt extends AmazonS3Ext
{
//	private AWSCredentials awsCredentials;
//	protected final List<Unmarshaller<AmazonServiceException, Node>> exceptionUnmarshallers;
//
//	private QueryStringSigner signer;
	
//	/**
//	 * <p>
//	 * Anonymous 사용자로 AmazonS3Client 확장 클라이언트를 구성한다.
//	 * </p>
//	 * <p>
//	 * AWSCredentials를 입력하지 않으면 Anonymous로 인증이 된다.
//	 * </p>
//	 * <ul>	
//	 * 	<li>지정한 버킷이 GroupGrantee.AllUsers에 Permission.Read로 설정되어 있다면 anonymous 클라이언트로 listObject(String)을 통해 버킷의 내용을 조회할 수 있다.</li>
//	 * 	<li>지정한 오브젝트가 GroupGrantee.AllUsers에 Permission.Read로 설정되어 있다면 anonymous 클라이언트로 getObject(String, String), getObjectMetadata(String, String)을 사용할 있다.</li>
//	 * </ul>
//	 * 
//	 * @see 	AmazonS3ClientExt(AWSCredentials)
//	 * @see		AmazonS3ClientExt(AWSCredentials, ClientConfiguration)
//	 */
//	public AmazonS3ClientExt ()
//	{
//		super ();
//	}
	
	/**
	 * <p>
	 * AWS credentials를 이용하여 AmazonS3Client 확장 클라이언트를 구성한다.
	 * </p>
	 * <i>
	 * in code:
	 * </i>
	 * <pre>
	 * new AmazonS3ClientExt (new PropertiesCredentials (AmazonS3ClientExt.class.getResourceAsStream ("Credentials.properties")))
	 * </pre>
	 * <i>
	 * in directory: Credentials.propertie
	 * </i>
	 * <pre>
	 * accessKey = AKIAICMOS3ZSOMLD7ADSFS
	 * secretKey = ibsVSba9AS/gF3ekPxsCl2wlW+ydf2bXihHclZDn
	 * </pre>
	 * 
	 * @param 	awsCredentials Request Header 구성 시 사용되는 인증 클래스.
	 * @see 	AmazonS3ClientExt()
	 * @see 	AmazonS3ClientExt(AWSCredentials, ClientConfiguration)
	 * @see		com.amazonaws.auth.AWSCredentials
	 * @see		com.amazonaws.auth.PropertiesCredentials
	 */
	public AmazonS3ClientExt(AWSCredentials awsCredentials) {
		super ( awsCredentials);
	}
	
	/**
	 * <p>
	 * AWS credentials과 CSS 서비스 엑세스 설정을 이용하여  AmazonS3Client 확장 클라이언트를 구성한다.
	 * </p>
	 * <i>
	 * in code:
	 * </i>
	 * <pre>
	 * new AmazonS3ClientExt (new PropertiesCredentials (AmazonS3ClientExt.class.getResourceAsStream ("Credentials.properties")), new ClientConfiguration ())
	 * </pre>
	 * <i>
	 * in directory: Credentials.propertie
	 * </i>
	 * <pre>
	 * accessKey = AKIAICMOS3ZSOMLD7ADSFS
	 * secretKey = ibsVSba9AS/gF3ekPxsCl2wlW+ydf2bXihHclZDn
	 * </pre>
	 * 
	 * @param 	awsCredentials awsCredentials Request Header 구성 시 사용되는 인증 클래스.
	 * @param 	clientConfiguration CSS 서비스에 접속하기 위한 옵션.
	 * @see 	AmazonS3ClientExt()
	 * @see		AmazonS3ClientExt(AWSCredentials)
	 * @see		com.amazonaws.auth.AWSCredentials
	 * @see		com.amazonaws.auth.PropertiesCredentials
	 */
	public AmazonS3ClientExt (AWSCredentials awsCredentials, ClientConfiguration clientConfiguration)
	{
		super (awsCredentials, clientConfiguration);
		
//		this.awsCredentials = awsCredentials;
//		
//		// TODO Exception 추가하거나 필요없는 부분 뺄 것.
//		exceptionUnmarshallers = new ArrayList<Unmarshaller<AmazonServiceException, Node>>();
//		exceptionUnmarshallers.add( new DuplicateCertificateExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new EntityAlreadyExistsExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new KeyPairMismatchExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new DeleteConflictExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new InvalidAuthenticationCodeExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new EntityTemporarilyUnmodifiableExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new MalformedCertificateExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new InvalidCertificateExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new MalformedPolicyDocumentExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new LimitExceededExceptionUnmarshaller() );
//		exceptionUnmarshallers.add( new NoSuchEntityExceptionUnmarshaller() );
//
//		exceptionUnmarshallers.add( new StandardErrorUnmarshaller() );
//
//		// TODO HOST 명 setting 할 것.
//		setEndpoint( "iam.localhost" );
//
//		signer = new QueryStringSigner();
//
//		HandlerChainFactory chainFactory = new HandlerChainFactory();
//		requestHandlers.addAll( chainFactory.newRequestHandlerChain( "/com/sk/services/css/request.handlers" ) );
	}
	
	@Override
	public void renameObject (String bucketName, String sourceKey, String newKeyName) 
			throws AmazonClientException,	AmazonServiceException
	{
		moveObject (bucketName, sourceKey, bucketName, sourceKey.substring (0, sourceKey.lastIndexOf ("/") + 1) + newKeyName);
	}

	@Override
	public void moveObject (String sourceBucketName, String sourceKey, String destinationBucketName, String destinationKey)
			throws AmazonClientException, AmazonServiceException
	{
		super.copyObject (sourceBucketName, sourceKey, destinationBucketName,  destinationKey);
		super.deleteObject (sourceBucketName, sourceKey);
	}

	@Override
	public Publishing putPublishing (String bucketName, String key,	Publishing pub) throws CSSException
	{
		Request<ExtClientRequest> request = new ExtClientRequestMarshaller().marshall( 
														new ExtClientRequest( bucketName, key ).withPublishing( pub ), 
														"PutPublishing"  );
		return invoke( request, new ExtClientResultStaxUnmarshaller() );
	}

	@Override
	public Publishing putPublishing (String bucketName, String key)	throws CSSException
	{
		Request<ExtClientRequest> request = new ExtClientRequestMarshaller().marshall( new ExtClientRequest( bucketName, key ), "PutPublishing"  );
		return invoke( request, new ExtClientResultStaxUnmarshaller() );
	}

	@Override
	public void createDirectory (String bucketName, String key) throws CSSException
	{
		Request<ExtClientRequest> request = new ExtClientRequestMarshaller().marshall( new ExtClientRequest( bucketName, key ), "CreateDirectory"  );
		invoke( request, null );
		
	}

	@Override
	public void setObjectMetadata (String bucketName, String key, Map<String, Object> metadata) throws CSSException
	{
		Request<ExtClientRequest> request = new ExtClientRequestMarshaller().marshall( new ExtClientRequest( bucketName, key ), "SetObjectMetadata"  );
		
		if (metadata != null) {
            for (Entry<String, Object> entry : metadata.entrySet()) {
                request.addHeader(Headers.S3_USER_METADATA_PREFIX + entry.getKey(), entry.getValue().toString());
            }
		}
	        
		invoke( request, null );
	}

	@Override
	public void deleteObjectMetadata (String bucketName, String key, String metadataKey) throws CSSException
	{
		Request<ExtClientRequest> request = new ExtClientRequestMarshaller().marshall( 
														new ExtClientRequest( bucketName, key ).withMetadataKey( metadataKey ), 
														"DeleteObjectMetadata"  );
		invoke( request, null );
	}
	
	private <X, Y extends AmazonWebServiceRequest> X invoke(Request<Y> request, Unmarshaller<X, StaxUnmarshallerContext> unmarshaller) {
		request.setEndpoint( endpoint );
		for (Entry<String, String> entry : request.getOriginalRequest().copyPrivateRequestParameters().entrySet()) {
			request.addParameter( entry.getKey(), entry.getValue() );
		}

		// Apply any additional service specific request handlers that need to be run
		if (requestHandlers != null) {
			for (RequestHandler requestHandler : requestHandlers) {
				requestHandler.beforeRequest( request );
			}
		}

		if (request.getOriginalRequest().getRequestCredentials() != null) {
			signer.sign( request, request.getOriginalRequest().getRequestCredentials() );
		} else {
			signer.sign( request, awsCredentials );
		}

		StaxResponseHandler<X> responseHandler = new StaxResponseHandler<X>( unmarshaller );
		DefaultErrorResponseHandler errorResponseHandler = new DefaultErrorResponseHandler( exceptionUnmarshallers );

		ExecutionContext executionContext = createExecutionContext();
		return ( X )client.execute( request, responseHandler, errorResponseHandler, executionContext );
	}
}
