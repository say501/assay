package com.sk.services.css.sample;

import java.io.File;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectMetadataRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.ListMultipartUploadsRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.Region;
import com.sk.services.css.AmazonS3ClientExt;
import com.sk.services.css.AmazonS3Ext;
import com.sk.services.css.model.Publishing;

public class SampleTest
{
	// This is used to connect to SKCloud.
//	private final String accessKeyId = "YANK0APMIDACKO23PEAN";
//	private final String secretAccessKey = "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";	
	private String endpoint = "http://s3.skcloud.com";
	
	// This is used to connect to AWS. Account is terryshim@naver.com
	//private final String accessKeyId = "AKIAIFFCMOS3ZSOMLD7A";
	//private final String secretAccessKey = "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";
	//private final String endpoint = "http://s3.amazonaws.com";
	
	//user name: U-20110821201022
	protected final String accessKeyId = "VIW1P9YYWSNMD6DVK9YP"; 
	protected final String secretAccessKey = "7p+BhenfAeP8QjUIbUP3ozAYMcWIBr92+jV04kj+";
		
	private AmazonS3 s3;
	private AmazonS3Ext client;
	
	@Before
	public void initialize ()
	{
		// 사용자 인증 설정
		CredentialSample cr = new CredentialSample (this.accessKeyId, this.secretAccessKey);
		
		// 인증된 AmazonS3 인스턴스를 얻어온다.
		this.s3 = cr.getAuthenticatedInstance ();
		
		// 목적지 서버 설정
		this.s3.setEndpoint (this.endpoint);
	}
	
	@Before
	public void initializeExt () 
	{
		this.client = new AmazonS3ClientExt (new BasicAWSCredentials (this.accessKeyId, this.secretAccessKey));
		this.client.setEndpoint (this.endpoint);
	}
	
	/********************************************************************************************
	 * 버킷 관련 기능
	 ********************************************************************************************/
	
	@Test
	public void listBucket ()
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.printBucketList ();
	}
	
	@Test
	public void infoBucket ()
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.printBucketInfo ("501-bucket");		
	}
	
	@Test
	public void createBucket ()
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.createBucket (new CreateBucketRequest ("bucket-503", Region.AP_Tokyo)); 
	}
	
	@Test
	public void deleteBucket ()
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.deleteBucket ("exbucket2");
	}
	
	@Test
	public void getBucketLocation ()
	{
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.printBucketLocation ("bucket-503");
	}
	
	/********************************************************************************************
	 * 오브젝트 관련 기능
	 ********************************************************************************************/
	
	@Test
	public void listObject ()
	{
		ObjectSample objectSample = new ObjectSample (s3);

		// Success.
		objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("5012").withPrefix ("test2"));

		// Failed.
		objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("notexist"));
	}
	
	@Test
	public void listObjectWithPrefix ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("bucket-503").withPrefix ("test/"));

		// Failed.
		objectSample.printObjectList (new ListObjectsRequest ().withBucketName ("bucket-503").withPrefix ("noexist/"));
	}
	
	@Test
	public void getObject ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.printObjectInfo (new GetObjectRequest ("bucket-503", "test.txt"));
		
		// Failed.
		objectSample.printObjectInfo (new GetObjectRequest ("bucket-503", "1.txt"));
	}
	
	@Test
	public void getMetadata ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.printObjectMetadata (new GetObjectMetadataRequest ("bucket-503", "test.txt"));
		
		// Failed.
		objectSample.printObjectMetadata (new GetObjectMetadataRequest ("bucket-503", "noexist.file"));
	}
	
	@Test
	public void getObjectAcl ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Absolute success.
		// This method is not supported. So result code is always 200 OK.
		objectSample.getObjectAcl ("501-bucket", "test.txt");
	}
	
	@Test
	public void uploadObject ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Create user metadata
		ObjectMetadata metadata = new ObjectMetadata ();
		metadata.addUserMetadata ("a", "hh");
		metadata.addUserMetadata ("d", "1111");
		
		// Success. ////////////////////////////////////////////////////////////////////////////////////////////
		// Create request for uploading object
		PutObjectRequest req = new PutObjectRequest ("bucket-503", "test.txt", new File ("D://", "test.txt"));
		req.setMetadata (metadata);

		// Upload object
		objectSample.uploadObjectByPut (req);
		////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		// Failed. /////////////////////////////////////////////////////////////////////////////////////////////
		// Create request for uploading object
		req = new PutObjectRequest ("noexist", "test.txt", new File ("D://", "test.txt"));
		req.setMetadata (metadata);

		// Upload object
		objectSample.uploadObjectByPut (req);
		////////////////////////////////////////////////////////////////////////////////////////////////////////
	}
	
	@Test
	public void deleteObject ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.deleteObject (new DeleteObjectRequest ("bucket-503", "test.txt"));
		
		// Failed.
		objectSample.deleteObject (new DeleteObjectRequest ("noexist", "a/version.ini"));
	}
	
	@Test
	public void listMultipartUpload ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		objectSample.printMultipartUploadList (new ListMultipartUploadsRequest ("bucket-503"));
	}
	
	@Test
	public void uploadMultipart ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		objectSample.uploadObjectByMultipart (new InitiateMultipartUploadRequest ("bucket-503", "restlet-1.1.10.zip"));
	}
	
	@Test
	public void abortMultipartUpload ()
	{
		ObjectSample objectSample = new ObjectSample (s3);
		
		// Success.
		objectSample.abortMultipartUpload (new AbortMultipartUploadRequest ("bucket-503", "restlet-1.1.10.zip", "4yyakBkIt4cJB4XTY_ZxRwuKVDM="));
		
		// Failed.
		objectSample.abortMultipartUpload (new AbortMultipartUploadRequest ("bucket-503", "restlet-1.1.10.zip", "noexistid"));
	}
	
	/********************************************************************************************
	 * 확장 기능
	 ********************************************************************************************/
	
	@Test
	public void setObjectMetadata ()
	{
		// Make user metadata.
		Map<String, Object> metadata = new HashMap<String, Object> ();
		metadata.put ("1", "one");
		metadata.put ("2", "two");
		metadata.put ("3", "ldaskjflasjdlfjlsajdflaj");
		metadata.put ("4", "four");
		metadata.put ("5", "five");

		// Set user metadata.
		// Success.
		this.client.setObjectMetadata ("bucket-503", "test.txt", metadata);
		// Failed.
		this.client.setObjectMetadata ("bucket-503", "noexist", metadata);
	}
	
	@Test
	public void deleteObjectMetadata ()
	{
		// Success.
		this.client.deleteObjectMetadata ("bucket-503", "test.txt", "1");
		
		// Failed.
		this.client.deleteObjectMetadata ("bucket-503", "noexist", "1");
	}
	
	@Test
	public void putObjectPublishing ()
	{
		// Success.
		Publishing result = this.client.putPublishing ("bucket-503", "test.txt");
		System.out.println (result.toString ());
		
		// Success.
		result = this.client.putPublishing ("bucket-503", "noexist");
		System.out.println (result.toString ());
	}
	
	@Test
	public void putObjectPublishingUsingExpiredate ()
	{		
		long after7day = 1000 * 3600 * 24 * 7;
		Timestamp expireDate = new Timestamp (new Date ().getTime () + after7day);

		Publishing pub = new Publishing ();
		pub.setGeneratedUri ("GeneralURI");
		pub.setExpireDate (expireDate);

		// Success.
		Publishing result = this.client.putPublishing ("bucket-503", "test.txt", pub);
		System.out.println (result.toString ());
		
		// Failed.
		result = this.client.putPublishing ("bucket-503", "noexist", pub);
		System.out.println (result.toString ());
	}
	
	@Test
	public void createDirectory ()
	{
		// Success.
		this.client.createDirectory ("bucket-503", "aaaaaa");
		
		// Failed.
		this.client.createDirectory ("bucket-503", "aaaaaa");
	}
}
