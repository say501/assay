package performance.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.Region;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.sk.services.css.sample.BucketSample;

public class S3TestUtil {
	
	//U-20110821201031
	private static final String accessKeyId = "2G18C3HG40H8007BH690";
	private static final String secretAccessKey = "IWLHSzYBzX86xSWN1+roY8wcszg6L6nuLsh0UDQv";
	
	//U-20110831180518
	//private static final String accessKeyId = "21HG870984DA52A8260B";
	//private static final String secretAccessKey = "Kb1sjRRCmHA2Nzrnf10Z/0Ca9J59OzC+RobDXoQo";
	
	
	private static String endpoint = "http://s3.skcloud.com";
	private static AmazonS3 s3 = new AmazonS3Client(new BasicAWSCredentials(accessKeyId, secretAccessKey));
	static { s3.setEndpoint(endpoint);	}
	
	public static final String TEST_BUCKET_NAME = "testbucket1";
	public static final String LOCAL_DATA_PATH 		= "/usr/local/s3perf/data/"; 	// C://testS3/  //test.dat의 경로
	public static final String RESULT_PATH	= "/usr/local/s3perf_result/";			///usr/local/s3perf/testresult/"; // C://testS3/
	
	///////////// Bucket Utilities //////////////////
	
	public static void listBucket (){
		List<Bucket> bList = s3.listBuckets();
		for (Bucket bucket : bList) 
		{
            System.out.println (bucket.toString ());
        }
		System.out.println(bList.size() + " Buckets");
	}
	public static void countBucket (){
		List<Bucket> bList = s3.listBuckets();
	
		System.out.println(bList.size() + " Buckets");
	}
	public static int getBucketCount (){
		return s3.listBuckets().size();
	}
	public static void infoBucket (String bucketName){
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.printBucketInfo (bucketName);
	}
	
	public static void createBucket(String bucketName){
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.createBucket (new CreateBucketRequest(bucketName, Region.AP_Tokyo)); 
	}
	

	public static void deleteBucket (String bucketName){
		BucketSample bucketSample = new BucketSample (s3);
		bucketSample.deleteBucket(bucketName);
	}
	

	public static void clearAllBucket ()
	{
		List<Bucket> bList = s3.listBuckets();
		BucketSample bSample = new BucketSample (s3);
		for(Bucket b: bList){
			bSample.deleteBucket(b.getName());
		}
	}

	/**
	 * delete all objects in a bucket and delete the bucket
	 * @param bn a bucket to empty
	 */
	public static void clearBucket(String bn) 
	{
		//String bn = "upload-object-test-bucket";// + getBucketNumber(i);
		try{
		if(s3.doesBucketExist(bn)){
			ObjectListing ol = s3.listObjects(bn);
	
			for(S3ObjectSummary obj: ol.getObjectSummaries()){
				try{
					s3.deleteObject(bn, obj.getKey());
				}catch(Exception e){System.out.println(e);}
			}
			s3.deleteBucket(bn);
		}
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	/**
	 * 
	 * @param bucketName
	 * @return true if bucketName exists; false if bucketName doesn't exist
	 */
	public static boolean hasBucket(String bucketName){
		return s3.doesBucketExist(bucketName);
	}
	
	/**
	 * @param num
	 * @return return 0000 format of num
	 */
	public static String formatBucketNumber(int num, int length){
		String bucketNumberStr = String.valueOf(num);
		String pad = "00000000000000000000000000000000000000000";
		bucketNumberStr = pad.substring(bucketNumberStr.length(), length) + bucketNumberStr;
		return bucketNumberStr;
	}
	
	private static int bucketNumber = 0;	// used in getBucketNumber() for sequential bucket naming
	public static int getBucketNumber(){ return bucketNumber++; }
	
	
	
	
	
	
	private static int range1 = 10000;
	private static int range2 = 20000;
	private static int range3 = 30000;
	/**
	 * @param format
	 * @return current time in format
	 * @throws UnknownHostException 
	 */
	public static String createBucketName() throws UnknownHostException {
		String host = InetAddress.getLocalHost().getHostName();
		int range = 1;
		String bucketName = "";
		if(host.equals("skcc-nebdap02")){ bucketName = "bucket-" + range1 + "-" + S3TestUtil.getCharacters(30); range1++;}
		else if(host.equals("skcc-nebdap03")){ bucketName = "bucket-" + range2 + "-" + S3TestUtil.getCharacters(30); range2++;}
		else if(host.equals("skcc-nebdap04")){ bucketName = "bucket-" + range3 + "-" + S3TestUtil.getCharacters(30); range3++;}
		else if(host.equals("SKCC07647")){ bucketName = "bucket-" + range3 + "-" + S3TestUtil.getCharacters(30); range3++;}
		else bucketName = "bucket-"  + System.nanoTime() + "-" + S3TestUtil.getCharacters(30, range);
		
		return bucketName;
		//return 	"bucket-"  + System.nanoTime() + "-" + S3TestUtil.getCharacters(30, range);
		//return 	"bucket-" + S3TestUtil.getTimeStamp("yyyyMMddHHmmss") + "-" + System.nanoTime() + "-" + S3TestUtil.getCharacters(20);
		//return 	"bucket-" + S3TestUtil.getTimeStamp("yyyyMMddHHmmss")+ "-" + formatBucketNumber(S3TestUtil.getBucketNumber(), 10) ;
	}
	
	///////////// Object Utilities //////////////////	

	public static void listObject(String bucketName)
	{
		try
		{
			ObjectListing objectLists = s3.listObjects(bucketName);
			
			long count = 0;
			for (S3ObjectSummary object : objectLists.getObjectSummaries ())
			{
				System.out.println (object.getKey () + " : " + 
									object.getSize () + " : " + 
									object.getOwner ().getDisplayName () + " : " + 
									object.getLastModified () + " : " + 
									object.getStorageClass ());
				count++;
			}
			System.out.println(count + " Objects");
		}
		catch (AmazonClientException e)
		{
			System.out.println(e);
		}
	}
	public static void countObject(String bucketName)
	{
		try
		{
			ObjectListing objectLists = s3.listObjects(bucketName);
			System.out.println(objectLists.getObjectSummaries().size());
		}catch (AmazonClientException e){
			System.out.println(e);
		}
	}
	/**
	 * List all objects in all buckets
	 * @param bucketName
	 */
	public static void countAllObject()
	{
		List<Bucket> bList = s3.listBuckets();
		long count = 0;
		for(Bucket b: bList){
			ObjectListing oList = s3.listObjects(b.getName());
			count += oList.getObjectSummaries().size();			
		}
		System.out.println(bList.size() + " Buckets " + count + " Objects");
	}
	
	public static String createObjectName(){
		return "object-" + S3TestUtil.getTimeStamp("yyyyMMddHHmmss") + "-" + S3TestUtil.getCharacters(40) + ".dat"; 
	}
	
	public static void clearAllObject (){
		List<Bucket> bList = s3.listBuckets();
		for(Bucket b: bList){
			clearBucket(b.getName());
		}
	}
	
	/////////// Miscellaneous Utilities ////////////	
	/**
	 * @param format
	 * @return current time in format
	 */
	public static String getTimeStamp(String format) {
		SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.KOREA);
		return formatter.format(new Date());
	}
	/**
	 * @param format
	 * @param milisec
	 * @return current time in format
	 */
	public static String getTimeStamp(String format, long milisec) {
		SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.KOREA);
		return formatter.format(milisec);
	}

	/**
	 * Returns a string with random characters
	 */
	public static String getCharacters(int length) {
		char ch[] = { 
				//  '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				//	'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
				//	'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
				'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
				'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
				'y', 'z'
		};

		Random rand = new Random();
		String str = "";

		StringBuffer sb = new StringBuffer(128);

		for (int j = 0; j < length; j++) {
			for (int k = 0; k < 1; k++) {
				sb.append(ch[rand.nextInt(26)]);
			}
		}

		str = sb.toString();
		return str;
	}
	
	/**
	 * 
	 * @param length
	 * @param range [1, 2, 3]
	 * @return
	 */
	public static String getCharacters(int length, int range) {
		char ch[] = new char[0];
		switch(range){
			case 1: ch = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};break;
			case 2: ch = new char[]{'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p'};break;
			case 3: ch = new char[]{'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};break;
		}
		
		Random rand = new Random();
		String str = "";

		StringBuffer sb = new StringBuffer(128);

		for (int j = 0; j < length; j++) {
			sb.append(ch[rand.nextInt(ch.length)]);
		}

		str = sb.toString();
		return str;
	}
	
	/**
	 * Writes text to a file; used for recording test results
	 * @param filename
	 * @param text
	 * @throws IOException 
	 */
	public static void writeTestResult(String filename, StringBuffer text) throws IOException{
		// write output to a file
		FileWriter fw = new FileWriter(new File(filename), true);
		fw.write(text.toString());		
		fw.close();
	}

	public static void main(String []args){
		//countBucket();clearAllBucket();
		
		//deleteBucket("testbucket");
		//infoBucket("testbucket");
		//countObject(S3TestUtil.TEST_BUCKET_NAME);
		//countBucket();
		//clearAllObject();
		//initAccount();
		//countAllObject();
		
		//listBucket();
		
		//createBucket("bucket-0000");
		//temp();
		countBucket();
	}
	/**
	 * Checks to see if all 1000 testing buckets are created properly 
	 */
	public static void temp(){
		List<Bucket> bList = s3.listBuckets();
		
		class MyComparator implements Comparator<Bucket>{
			@Override
			public int compare(Bucket o1, Bucket o2) {	return o1.getName().compareTo(o2.getName());	}			
		}
		
		Collections.sort(bList, new MyComparator());
		int j=0;
		for(int i=0;i<1000; i++){
			
			if(bList.size()<=i){
				createBucket("bucket-" + S3TestUtil.formatBucketNumber(i,4));
			}else if(!bList.get(j).getName().equals("bucket-" + S3TestUtil.formatBucketNumber(i,4))){
				
				createBucket("bucket-" + S3TestUtil.formatBucketNumber(i,4));
				System.out.println(bList.get(j).getName()+" "+i);

			}else{j++;}
		}		
	}
	/**
	 * initialize an account to 1000 buckets with 100 objects in each
	 */
	public static void initAccount(){
		
		// 모든 버킷 삭제 

		// 버킷 1000개 생성 
		for(int i=0;i<1000;i++){		
			try {
				String bucketName = "bucket-" + formatBucketNumber(i, 4);
				createBucket(bucketName);
				
				/*// & 각 버킷마다 오브젝트 100개 업로드
				for(int j=0;j<10;j++){ 
					ObjectSample objectSample = new ObjectSample (s3);
					String objectName = "object-" + S3TestUtil.getCharacters(3) + "-" + S3TestUtil.getTimeStamp("yyyyMMddHHmmss")+".txt"; 
					PutObjectRequest req = new PutObjectRequest(bucketName, objectName, new File ("C://", "test.dat"));
				
					// 	Create user metadata //
					ObjectMetadata metadata = new ObjectMetadata ();
					metadata.addUserMetadata ("key1", "test value 1");
					metadata.addUserMetadata ("key2", "test value 2");
					req.setMetadata (metadata);
				
					// upload
					objectSample.uploadObjectByPut (req);
				}*/
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
