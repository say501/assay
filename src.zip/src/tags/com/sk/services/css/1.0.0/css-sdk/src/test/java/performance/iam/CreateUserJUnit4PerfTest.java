package performance.iam;

import junit.framework.Test;
import junit.framework.TestSuite;
import performance.JUnit4PefFactory;

import com.clarkware.junitperf.ConstantTimer;
import com.clarkware.junitperf.LoadTest;
import com.clarkware.junitperf.TimedTest;
import com.clarkware.junitperf.Timer;

/**
 * 
 * @author Ryan GG Ahn
 *
 */
public class CreateUserJUnit4PerfTest {
	public static Test throughtputUnderLoadTest() {
		int maxUsers = 3;
		int iterations = 1;
		Timer timer = new ConstantTimer( 2000 );

		JUnit4PefFactory factory = new JUnit4PefFactory( CreatUser.class );
		
		TestSuite testCase = factory.makeTestSuite();
		Test loadTest = new LoadTest( testCase, maxUsers, iterations, timer );
		
		long maxElapsedTime = 5000;
		Test timedTest = new TimedTest( loadTest, maxElapsedTime );
		
		return timedTest;
	}
	
//	public static Test responseTimeUnderLoadTest() {
//		int maxUsers = 3;
//		long maxElapsedTime = 10000;
//		
//		JUnit4PefFactory factory = new JUnit4PefFactory( CreatUser.class );
//		
//		TestSuite testCase = factory.makeTestSuite();
//		Test timedTest = new TimedTest( testCase, maxElapsedTime );
//		
//		Test loadTest = new LoadTest( timedTest, maxUsers );
//		
//		return loadTest;
//	}
	
	public static Test defaultLoadTestSuite() {
		int users = 1;
		int iterations = 1;
		Timer timer = new ConstantTimer( 3000 );
		
		JUnit4PefFactory factory = new JUnit4PefFactory( CreatUser.class );
		
		TestSuite testCase = factory.makeTestSuite();
		Test loadTest = new LoadTest( testCase, users, iterations, timer );
		
		return loadTest;
	}
	
//	public static Test loadTestSuite() {
//		int users = 10;
//		int iterations = 1;
//		Timer timer = new ConstantTimer( 3000 );
//		
//		JUnit4PefFactory factory = new JUnit4PefFactory( CreatUser.class );
//		
//		TestSuite testCase = factory.makeTestSuite();
//		Test loadTest = new LoadTest( testCase, users, iterations, timer );
//		
//		long maxElapsedTime = 1500;
//		Test timedTest = new TimedTest( loadTest, maxElapsedTime );//  new TimedTest(loadTest, maxElapsedTime);
//		
//		return loadTest;
//	}
	
	public static void main(String[] args) {
		long startTime = System.nanoTime();
		System.out.println( startTime);
		junit.textui.TestRunner.run( throughtputUnderLoadTest() );
		
		long endTiem = System.nanoTime();
		System.out.println( "걸린시간" + (endTiem - startTime));
		
		//junit.textui.TestRunner.run( defaultLoadTestSuite() );
		//junit.textui.TestRunner.run( responseTimeUnderLoadTest() );
	}
}
