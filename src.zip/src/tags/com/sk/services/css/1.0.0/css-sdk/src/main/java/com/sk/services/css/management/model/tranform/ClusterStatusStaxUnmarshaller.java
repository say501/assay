/*
 * Copyright 2010-2011 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 * 
 *  http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.sk.services.css.management.model.tranform;

import java.util.HashMap;
import java.util.Map;

import javax.xml.stream.events.XMLEvent;

import com.amazonaws.transform.SimpleTypeStaxUnmarshallers.StringStaxUnmarshaller;
import com.amazonaws.transform.StaxUnmarshallerContext;
import com.amazonaws.transform.Unmarshaller;

public class ClusterStatusStaxUnmarshaller implements Unmarshaller<Map<String, String>, StaxUnmarshallerContext> {

	public Map<String, String> unmarshall(StaxUnmarshallerContext context) throws Exception {
		Map<String, String> cs = new HashMap<String, String>();
		
		int originalDepth = context.getCurrentDepth();
		int targetDepth = originalDepth + 1;

		if (context.isStartOfDocument())
			targetDepth += 2;

		while (true) {
			XMLEvent xmlEvent = context.nextEvent();
			if (xmlEvent.isEndDocument())
				return cs;

			if (xmlEvent.isAttribute() || xmlEvent.isStartElement()) {

				if (context.testExpression( "Path", targetDepth )) {
					cs.put( "Path", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
				if (context.testExpression( "Dirs", targetDepth )) {
					cs.put( "Dirs", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
				if (context.testExpression( "Files", targetDepth )) {
					cs.put( "Files", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
				if (context.testExpression( "Du_used_u", targetDepth )) {
					cs.put( "Du_used_u", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
				if (context.testExpression( "Du_used_p", targetDepth )) {
					cs.put( "Du_used_p", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
				if (context.testExpression( "Du_free_u", targetDepth )) {
					cs.put( "Du_free_u", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
				if (context.testExpression( "Du_free_p", targetDepth )) {
					cs.put( "Du_free_p", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
				if (context.testExpression( "Op_create", targetDepth )) {
					cs.put( "Op_create", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
				if (context.testExpression( "Op_unlink", targetDepth )) {
					cs.put( "Op_unlink", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
//				if (context.testExpression( "Op_speed", targetDepth )) {
//					cs.put( "Op_speed", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
//					continue;
//				}
				if (context.testExpression( "Op_write", targetDepth )) {
					cs.put( "Op_write", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
				if (context.testExpression( "Op_read", targetDepth )) {
					cs.put( "Op_read", StringStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
			} else if (xmlEvent.isEndElement()) {
				if (context.getCurrentDepth() < originalDepth) {
					return cs;
				}
			}
		}
	}

	private static ClusterStatusStaxUnmarshaller instance;

	public static ClusterStatusStaxUnmarshaller getInstance() {
		if (instance == null)
			instance = new ClusterStatusStaxUnmarshaller();
		return instance;
	}
}
