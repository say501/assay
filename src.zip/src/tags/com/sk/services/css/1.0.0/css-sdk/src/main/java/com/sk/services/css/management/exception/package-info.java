/**
 * SK CSS Exception API.
 */
package com.sk.services.css.management.exception;
