package a_customerTest;

import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.auth.BasicAWSCredentials;
import com.sk.services.css.AmazonS3ClientExt;
import com.sk.services.css.AmazonS3Ext;
import com.sk.services.css.model.Publishing;

public class TS103 {
	private final static String accessKeyId = "YANK0APMIDACKO23PEAN";
	private final static String secretAccessKey = "9yRWf8B1lTBs2B5JfFHmhGb3TcGhHJHwdksmUo4e";
	private String devUrl = "http://s3.skcloud.com";
	private AmazonS3Ext client = null;
	
	@Before
	public void setUp() throws Exception {
		client = new AmazonS3ClientExt( new BasicAWSCredentials( accessKeyId, secretAccessKey ) );
		assertNotNull( client );
		client.setEndpoint( devUrl );
	}
	
	@Test
	public void TS103_TC_03_and_06_Test()  throws Exception {
		this.TS103_TC_03_and_06();
	}
	@Test
	public void TS103_TC_03_and_06() { //test_PutPublishing_Using_Publishing(
		
		String bucketName = "bucket-503";
		String key = "test.txt";
		
		SimpleDateFormat formatter = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss", Locale.KOREA );
		String format = formatter.format( new Date() );
		
		System.out.println( format );
		
		Publishing pub = new Publishing();
		pub.setGeneratedUri( "GeneralURI" );
		pub.setExpireDate( Timestamp.valueOf( format ) );
		
		Publishing result = client.putPublishing( bucketName, key, pub );
		
		assertNotNull( result );
		System.out.println( result.toString() );
	}
		
	@Test
	public void test_CreateDirectory() {
		String bucketName = "newbucket";
		String key = "movie.sql";
		client.createDirectory( bucketName, key );
	}

	@Test
	public void test_SetObjectMetadata() {
		
		String bucketName = "newbucket";
		String key = "movie.sql";
		
		@SuppressWarnings("serial")
		Map<String, Object> metadata = new HashMap<String, Object>() {{
			put( "1", "one" );
			put( "2", "two" );
			put( "3", "three" );
			put( "4", "four" );
			put( "5", "five" );
		}};
		
		client.setObjectMetadata( bucketName, key, metadata );
	}

	@Test
	public void test_DeleteObjectMetadata() {
		//String bucketName = "ryan";
		//String key = "test.pdf";
		String bucketName = "newbucket";
		String key = "movie.sql";
		String metadataKey = "one";
		client.deleteObjectMetadata( bucketName, key, metadataKey );
	}



}
