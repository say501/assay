package com.sk.services.css.management.model.tranform;

import javax.xml.stream.events.XMLEvent;

import com.amazonaws.transform.StaxUnmarshallerContext;
import com.amazonaws.transform.Unmarshaller;
import com.sk.services.css.management.model.ListClusterResult;

public class ListClusterResultStaxUnmarshaller implements Unmarshaller<ListClusterResult, StaxUnmarshallerContext> {
	@Override
	public ListClusterResult unmarshall(StaxUnmarshallerContext context) throws Exception {
		ListClusterResult listClustersResult = new ListClusterResult();
		int originalDepth = context.getCurrentDepth();
		int targetDepth = originalDepth + 1;

		if (context.isStartOfDocument())
			targetDepth += 2;

		while (true) {
			XMLEvent xmlEvent = context.nextEvent();
			if (xmlEvent.isEndDocument())
				return listClustersResult;

			if (xmlEvent.isAttribute() || xmlEvent.isStartElement()) {
				if (context.testExpression( "Clusters/Cluster", targetDepth )) {
					listClustersResult.getClusters().add( ClusterStaxUnmarshaller.getInstance().unmarshall( context ) );
					continue;
				}
			} else if (xmlEvent.isEndElement()) {
				if (context.getCurrentDepth() < originalDepth) {
					return listClustersResult;
				}
			}
		}
	}

	private static ListClusterResultStaxUnmarshaller instance;

	public static ListClusterResultStaxUnmarshaller getInstance() {
		if (instance == null)
			instance = new ListClusterResultStaxUnmarshaller();
		return instance;
	}
}
