package com.sk.services.css.model.tranform;

import java.sql.Timestamp;

import javax.xml.stream.events.XMLEvent;

import com.amazonaws.transform.SimpleTypeStaxUnmarshallers.StringStaxUnmarshaller;
import com.amazonaws.transform.StaxUnmarshallerContext;
import com.amazonaws.transform.Unmarshaller;
import com.sk.services.css.model.Publishing;

public class ExtClientResultStaxUnmarshaller implements Unmarshaller<Publishing, StaxUnmarshallerContext> {

	@Override
	public Publishing unmarshall(StaxUnmarshallerContext context) throws Exception {
		Publishing publishing = new Publishing();

		int originalDepth = context.getCurrentDepth();
		int targetDepth = originalDepth + 1;

		if (context.isStartOfDocument())
			targetDepth += 2;

		while (true) {
			XMLEvent xmlEvent = context.nextEvent();
			if (xmlEvent.isEndDocument())
				return publishing;
			
			if (xmlEvent.isAttribute() || xmlEvent.isStartElement()) {
				//if (context.testExpression( "Publishing", targetDepth )) {
					if (context.testExpression( "GeneratedUri", targetDepth )) {
						publishing.setGeneratedUri( StringStaxUnmarshaller.getInstance().unmarshall( context ) );
						continue;
					}

					if (context.testExpression( "ExpireDate", targetDepth )) {
						publishing.setExpireDate( Timestamp.valueOf( StringStaxUnmarshaller.getInstance().unmarshall( context ) ) );
						continue;
					}
				//}
			}
			
			

//			if (xmlEvent.isAttribute() || xmlEvent.isStartElement()) {
//				if (context.testExpression( "GeneratedUri", targetDepth )) {
//					publishing.setGeneratedUri( StringStaxUnmarshaller.getInstance().unmarshall( context ) );
//					continue;
//				}
//
//				if (context.testExpression( "ExpireDate", targetDepth )) {
//					publishing.setExpireDate( Timestamp.valueOf( StringStaxUnmarshaller.getInstance().unmarshall( context ) ) );
//					continue;
//				}
//			} 
			else if (xmlEvent.isEndElement()) {
				if (context.getCurrentDepth() < originalDepth) {
					return publishing;
				}
			}
		}
	}

//	private void setParameters(StaxUnmarshallerContext context) {
//		while (true) {
//			XMLEvent xmlEvent = context.nextEvent();
//
//			if (xmlEvent.isAttribute() || xmlEvent.isStartElement()) {
//				if (context.testExpression( "GeneratedUri", targetDepth )) {
//					publishing.setGeneratedUri( StringStaxUnmarshaller.getInstance().unmarshall( context ) );
//					continue;
//				}
//
//				if (context.testExpression( "ExpireDate", targetDepth )) {
//					publishing.setExpireDate( Timestamp.valueOf( StringStaxUnmarshaller.getInstance().unmarshall( context ) ) );
//					continue;
//				}
//			} else if (xmlEvent.isEndElement()) {
//				if (context.getCurrentDepth() < originalDepth) {
//					return publishing;
//				}
//			}
//		}
//	}

	private static ExtClientResultStaxUnmarshaller instance;

	public static ExtClientResultStaxUnmarshaller getInstance() {
		if (instance == null)
			instance = new ExtClientResultStaxUnmarshaller();
		return instance;
	}

}
