package com.sk.services.css.management;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.w3c.dom.Node;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.AmazonWebServiceClient;
import com.amazonaws.AmazonWebServiceRequest;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.Request;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.QueryStringSigner;
import com.amazonaws.handlers.HandlerChainFactory;
import com.amazonaws.handlers.RequestHandler;
import com.amazonaws.http.DefaultErrorResponseHandler;
import com.amazonaws.http.ExecutionContext;
import com.amazonaws.http.StaxResponseHandler;
import com.amazonaws.transform.StandardErrorUnmarshaller;
import com.amazonaws.transform.StaxUnmarshallerContext;
import com.amazonaws.transform.Unmarshaller;
import com.sk.services.css.management.exception.CSSException;
import com.sk.services.css.management.model.Cluster;
import com.sk.services.css.management.model.ClusterRequest;
import com.sk.services.css.management.model.ListClusterRequest;
import com.sk.services.css.management.model.ListClusterStatusRequest;
import com.sk.services.css.management.model.tranform.ClusterRequestMarshaller;
import com.sk.services.css.management.model.tranform.ClusterResultStaxUnmarshaller;
import com.sk.services.css.management.model.tranform.ListClusterRequestMarshaller;
import com.sk.services.css.management.model.tranform.ListClusterResultStaxUnmarshaller;
import com.sk.services.css.management.model.tranform.ListClusterStatusRequestMarshaller;
import com.sk.services.css.management.model.tranform.ListClusterStatusResultStaxUnmarshaller;

/**
 * <p>
 * SK CSS 관리 서비스에 엑세스 하기 위한 구현체를 제공한다.
 * </p>
 * SK CSS는 인터넷 환경에서 스토리지 공간을 제공하고, 개발자를 위해 쉽게 웹 확장 기능을 만들 수 있게 디자인 되어 있다.
 * <p>
 * SK CSS Java SDK는 언제, 어디서든지 웹 환경에서 아무 데이터나 검색하고 보관하는 용도로 사용될 있도록 간단한 인터페이스를 제공한다. 개발자 누구든 동일하게 SK는 웹 사이트의 글로벌 네트워크로 운용되어 높은 확장성, 신뢰성, 보안성, 속도 그리고 저렴한 인프라를
 * 엑세스할 수 있게 해준다. 이 서비스는 확장에 대한 장점을 확보하는 것과 개발자에게로 돌아가는 이익을 최소화 하는 것이 목적이다.
 * </p>
 * <p>
 * SK CSS에 대한 더 많은 정보는 <a href="http://doc.micloud.kr/java">http://doc.micloud.kr/java</a>에서 확인할 수 있다.
 * </p>
 * 
 */
public class CSSManagementClient extends AmazonWebServiceClient implements CSSManagement {

	private AWSCredentials												awsCredentials;
	protected final List<Unmarshaller<AmazonServiceException, Node>>	exceptionUnmarshallers;

	private QueryStringSigner											signer;

	/**
	 * <p>
	 * AWS credentials를 이용하여 CSS 클라이언트를 구성한다.
	 * </p>
	 * <i> in code: </i>
	 * 
	 * <pre>
	 * new CSSManagementClient( new PropertiesCredentials( CSSManagementClient.class.getResourceAsStream( &quot;Credentials.properties&quot; ) ) )
	 * </pre>
	 * 
	 * <i> in directory: Credentials.propertie </i>
	 * 
	 * <pre>
	 * accessKey = AKIAICMOS3ZSOMLD7ADSFS
	 * secretKey = ibsVSba9AS/gF3ekPxsCl2wlW+ydf2bXihHclZDn
	 * </pre>
	 * 
	 * @param awsCredentials
	 *            Request Header 구성 시 사용되는 인증 클래스.
	 * @see CSSManagementClient#CSSManagementClient()
	 * @see CSSManagementClient#CSSManagementClient(AWSCredentials, ClientConfiguration)
	 * @see com.amazonaws.auth.AWSCredentials
	 * @see com.amazonaws.auth.PropertiesCredentials
	 */
	public CSSManagementClient(AWSCredentials awsCredentials) {
		this( awsCredentials, new ClientConfiguration() );
	}

	/**
	 * <p>
	 * AWS credentials과 CSS 서비스 엑세스 설정을 이용하여 CSS 클라이언트를 구성한다.
	 * </p>
	 * <i> in code: </i>
	 * 
	 * <pre>
	 * new CSSManagementClient( new PropertiesCredentials( CSSManagementClient.class.getResourceAsStream( &quot;Credentials.properties&quot; ) ), new ClientConfiguration() )
	 * </pre>
	 * 
	 * <i> in directory: Credentials.propertie </i>
	 * 
	 * <pre>
	 * accessKey = AKIAICMOS3ZSOMLD7ADSFS
	 * secretKey = ibsVSba9AS/gF3ekPxsCl2wlW+ydf2bXihHclZDn
	 * </pre>
	 * 
	 * @param awsCredentials
	 *            awsCredentials Request Header 구성 시 사용되는 인증 클래스.
	 * @param clientConfiguration
	 *            CSS 서비스에 접속하기 위한 옵션.
	 * @see CSSManagementClient#CSSManagementClient()
	 * @see CSSManagementClient#CSSManagementClient(AWSCredentials)
	 * @see com.amazonaws.auth.AWSCredentials
	 * @see com.amazonaws.auth.PropertiesCredentials
	 */
	public CSSManagementClient(AWSCredentials awsCredentials, ClientConfiguration clientConfiguration) {
		super( clientConfiguration );

		this.awsCredentials = awsCredentials;
		// TODO Exception 추가하거나 필요없는 부분 뺄 것.
		exceptionUnmarshallers = new ArrayList<Unmarshaller<AmazonServiceException, Node>>();
		// exceptionUnmarshallers.add( new DuplicateCertificateExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new EntityAlreadyExistsExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new KeyPairMismatchExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new DeleteConflictExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new InvalidAuthenticationCodeExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new EntityTemporarilyUnmodifiableExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new MalformedCertificateExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new InvalidCertificateExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new MalformedPolicyDocumentExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new LimitExceededExceptionUnmarshaller() );
		// exceptionUnmarshallers.add( new NoSuchEntityExceptionUnmarshaller() );

		exceptionUnmarshallers.add( new StandardErrorUnmarshaller() );

		// TODO HOST 명 setting 할 것.
		setEndpoint( "http://iam.localhost" );

		signer = new QueryStringSigner();

		HandlerChainFactory chainFactory = new HandlerChainFactory();
		requestHandlers.addAll( chainFactory.newRequestHandlerChain( "/com/sk/services/css/request.handlers" ) );
	}

	public boolean intialize() {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @deprecated {@link listCluster()} 참조
	 */
	public List<String> listVolume() throws CSSException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Cluster> listCluster() throws Exception {
		Request<ListClusterRequest> request = new ListClusterRequestMarshaller().marshall( new ListClusterRequest() );
		return invoke( request, new ListClusterResultStaxUnmarshaller() ).getClusters();
	}

	public long getObjectCount(String key, int mode, int type) throws CSSException {

		isValid( key );

		Request<ClusterRequest> request = new ClusterRequestMarshaller().marshall( new ClusterRequest().withKey( key ).withMode( String.valueOf( mode ) )
				.withType( String.valueOf( type ) ), "ObjectCount" );
		return invoke( request, new ClusterResultStaxUnmarshaller() ).getCount();
	}

	public long getObjectCount(String bucketName, String key, int mode, int type) throws CSSException {

		isValid( bucketName, key );

		Request<ClusterRequest> request = new ClusterRequestMarshaller().marshall(
				new ClusterRequest().withBucketName( bucketName ).withKey( key ).withMode( String.valueOf( mode ) ).withType( String.valueOf( type ) ),
				"ObjectCountByBucketName" );
		return invoke( request, new ClusterResultStaxUnmarshaller() ).getCount();
	}

	/**
	 * @deprecated
	 */
	@Deprecated
	public long getObjectSize(String key, int mode) throws CSSException {
		Request<ClusterRequest> request = new ClusterRequestMarshaller().marshall( new ClusterRequest().withKey( key ).withMode( String.valueOf( mode ) ),
				"ObjectSize" );
		return invoke( request, new ClusterResultStaxUnmarshaller() ).getCount();
	}

	public long getObjectSize(String bucketName, String key, int mode) throws CSSException {

		isValid( bucketName, key );

		Request<ClusterRequest> request = new ClusterRequestMarshaller().marshall(
				new ClusterRequest().withBucketName( bucketName ).withKey( key ).withMode( String.valueOf( mode ) ), "ObjectSize" );
		return invoke( request, new ClusterResultStaxUnmarshaller() ).getCount();
	}

	/**
	 * @deprecated {@link getClusterCount(String, int, int)} 참조
	 */
	public long getVolumeCount(String volumeName, int mode, int type) throws CSSException {
		// TODO Auto-generated method stub
		return 0;
	}

	public long getClusterCount(String volumeName, int mode, int type) throws CSSException {

		isValid( volumeName );
		Request<ClusterRequest> request = new ClusterRequestMarshaller().marshall(
				new ClusterRequest( volumeName, String.valueOf( mode ) ).withType( String.valueOf( type ) ), "ClusterCount" );
		return invoke( request, new ClusterResultStaxUnmarshaller() ).getCount();
	}

	/**
	 * @deprecated {@link getClusterSize(String, int)} 참조
	 */
	public long getVolumeSize(String volumeName, int mode) throws CSSException {
		// TODO Auto-generated method stub
		return 0;
	}

	public long getClusterSize(String volumeName, int mode) throws CSSException {
		isValid( volumeName );
		Request<ClusterRequest> request = new ClusterRequestMarshaller().marshall( new ClusterRequest( volumeName, String.valueOf( mode ) ), "ClusterSize" );
		return invoke( request, new ClusterResultStaxUnmarshaller() ).getCount();
	}

	/**
	 * @deprecated {@link getClusterFreeSize(String, int)} 참조
	 */
	public long getVolumeFreeSize(String volumeName, int mode) throws CSSException {
		// TODO Auto-generated method stub
		return 0;
	}

	public long getClusterFreeSize(String volumeName, int mode) throws CSSException {
		isValid( volumeName );

		Request<ClusterRequest> request = new ClusterRequestMarshaller().marshall( new ClusterRequest( volumeName, String.valueOf( mode ) ), "ClusterFreeSize" );
		return invoke( request, new ClusterResultStaxUnmarshaller() ).getCount();
	}

	private void isValid(String... param) throws CSSException {
		for (String str : param) {
			if (str == null || str.length() == 0 || "null".equalsIgnoreCase( str ))
				throw new CSSException( " 입력한 parameter는  null이나 \"\" 가 될 수 없습니다." );
		}
	}

	/**
	 * @deprecated {@link listClusterStatus(String)} 참조
	 */
	public Map<String, String> listVolumeStatus(String volumeName) throws CSSException {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<String, String> listClusterStatus(String volumeName) throws CSSException {
		Request<ListClusterStatusRequest> request = new ListClusterStatusRequestMarshaller().marshall( new ListClusterStatusRequest( volumeName ) );
		return invoke( request, new ListClusterStatusResultStaxUnmarshaller() ).getListClusterStatus();
	}

	private <X, Y extends AmazonWebServiceRequest> X invoke(Request<Y> request, Unmarshaller<X, StaxUnmarshallerContext> unmarshaller) {
		request.setEndpoint( endpoint );
		for (Entry<String, String> entry : request.getOriginalRequest().copyPrivateRequestParameters().entrySet()) {
			request.addParameter( entry.getKey(), entry.getValue() );
		}

		// Apply any additional service specific request handlers that need to
		// be run
		if (requestHandlers != null) {
			for (RequestHandler requestHandler : requestHandlers) {
				requestHandler.beforeRequest( request );
			}
		}

		if (request.getOriginalRequest().getRequestCredentials() != null) {
			signer.sign( request, request.getOriginalRequest().getRequestCredentials() );
		} else {
			signer.sign( request, awsCredentials );
		}

		StaxResponseHandler<X> responseHandler = new StaxResponseHandler<X>( unmarshaller );
		DefaultErrorResponseHandler errorResponseHandler = new DefaultErrorResponseHandler( exceptionUnmarshallers );

		ExecutionContext executionContext = createExecutionContext();
		return (X) client.execute( request, responseHandler, errorResponseHandler, executionContext );
	}
}
